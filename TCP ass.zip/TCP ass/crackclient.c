#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdbool.h>
#include <csse2310a3.h>
#include <csse2310a4.h>
#include <crypt.h>
#include <arpa/inet.h>
#include <netdb.h>

#define MAXINPUTJOBLINELEN 80
#define NEWLINE '\n'
#define STREND '\0'
#define WELL '#'
#define INVALID ":invalid\n"
#define FAIL ":failed\n"

//emit error messages then exit when job file is null
void print_fail_to_open_jobfiles(char* jobFileName) {
    fprintf(stderr, "crackclient: unable to "
	    "open job file \"%s\"\n", jobFileName);
    exit(2);
}

//when connection terminated, emit erro message
void print_connection_terminated() {
    fprintf(stderr, "crackclient: server connection terminated\n");
    exit(4);
}

int main(int argc, char** argv) {
    //check command line
    if (argc < 2 || argc > 4) {	    
        fprintf(stderr, "Usage: crackclient portnum [jobfile]\n");
        exit(1);
    }
    if (argc == 3) {
	FILE* op = fopen(argv[2], "r");
	if (op == NULL) {
	    print_fail_to_open_jobfiles(argv[2]);
	    fclose(op);
	    exit(2);
	}
	fclose(op);
    }
    //REF code below for connection is modified by the
    //code shown on the lecture
    const char* port = argv[1];
    struct addrinfo* ai = 0;
    struct addrinfo hints;
    memset(&hints, 0, sizeof(struct addrinfo));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    int err;
    if ((err = getaddrinfo("localhost", port, &hints, &ai))) {
	freeaddrinfo(ai);
	fprintf(stderr, "crackclient: unable to connect to port %s\n", port);
	exit(3);
    }

    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (connect(fd, ai->ai_addr, sizeof(struct sockaddr))) {
        fprintf(stderr, "crackclient: unable to connect to port %s\n", port);
	exit(3);
    }           	
    char buffer[MAXINPUTJOBLINELEN];
    int len;
    ssize_t bytes;
    //send and receive file
    if (argc == 3) {
	//REF this code is modified from the lecture
	int fd2 = dup(fd);
        FILE* to = fdopen(fd, "w");
	FILE* from = fdopen(fd2, "r");
	FILE* op = fopen(argv[2], "r");
	while (fgets(buffer, MAXINPUTJOBLINELEN, op)) {
            len = strlen(buffer);
	    //check the job is valid
            if (buffer[0] == WELL || buffer[0] == NEWLINE) {
	        continue;
	    }
            fprintf(to, "%s", buffer);
	    fflush(to);
	    fgets(buffer, 80, from);
	    if (strcmp(buffer, INVALID) == 0) {
	        fprintf(stdout, "Error in command\n");
	    } else if (strcmp(buffer, FAIL) == 0) {
	        fprintf(stdout, "Unable to decrypt\n");
	    } else {
	        fprintf(stdout, "%s\n", buffer);
	    }
	}
	fclose(to);
	fclose(from);
	close(fd);
	fclose(op);
	FILE* p = fopen(argv[2], "r");
        int jobFd = fileno(p);
        fclose(p);
        if (jobFd == fd) {
	    print_connection_terminated();
	}
	exit(0);
    } else {
	memset(buffer, 0, sizeof(buffer) + 1);
        while (fgets(buffer, MAXINPUTJOBLINELEN, stdin)) {
	    len = strlen(buffer);
	    for (int i = 0; i <= len; i++) {
		if (buffer[i] == EOF) {
		    close(fd);
		    exit(0);
		}
		if (buffer[i] == '\n') {
		    buffer[i] = '\0';
		}
	    }
	    bytes = write(fd, buffer, sizeof(buffer));
	    if (bytes <= 0) {
	        print_connection_terminated();
	    }
	    bytes = read(fd, buffer, sizeof(buffer));
	    if (bytes <= 0) {
	        print_connection_terminated();
	    }
	    if (strcmp(buffer, INVALID) == 0) {
	        fprintf(stdout, "Error in command\n");
	    } else if (strcmp(buffer, FAIL) == 0) {
	        fprintf(stdout, "Unable to decrypt\n");
	    } else {
	        fprintf(stdout, "%s", buffer);
	    }
	}
    }
}

