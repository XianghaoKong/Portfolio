#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <csse2310a4.h>
#include <ctype.h>
#include <csse2310a3.h>
#include <crypt.h>
#include <signal.h>

#define NEWLINE '\n'         
#define STREND '\0'          
#define MAXVALIDWORDLEN 8    
#define MINVALIDWORDLEN 1    
#define MAXINPUTWORDLEN 52   
#define BUFFERLEN 50        
#define SUBSTRNUM 3        
#define SPACEBAR ' '         
#define REQUESTYPELOC 0     
#define REQUESTWORDLOC 1    
#define SALTORTHREADLOC 2    
#define FLAGTRUE 1           
#define FLAGFALSE 0          
#define MAXTHREADNUM 50      
#define MINTHREADNUM 1       
#define SALTLEN 2            
#define CIPHERLEN 13        
#define DOT '.'             
#define SLANT '/'            

//define global variables
int currentConN = 0;    //current connection num
int totalConN = 0;      //total connection num
int crackReqNum = 0;    //crackrequest num
int failCrackNum = 0;   //crack failed times
int succCrackNum = 0;   //crack successed times
int cryptReqNum = 0;    //crypt request time
int callNum = 0;        //crypt call times

//define mutex and condition
pthread_mutex_t crackMutex;     //protect when crack
pthread_cond_t cond;            //limit connection beyond specified
pthread_mutex_t conNmutex;      //protect connect num
pthread_mutex_t cryptReqMutex;  //protect cetpr request times
pthread_mutex_t callMutex;      //protect crypt()call times
pthread_mutex_t crackReqMutex;  //protect crack request times
pthread_mutex_t failCrackMutex; //protect crack fail times
pthread_mutex_t succCrackMutex; //protect succeeded crack times

//difine SIGHUP handler
void sighup_handler(int sig) {
    if (sig == SIGHUP) {
       	fprintf(stderr, "Connected clients: %d\n"
	        "Completed clients: %d\n"
	        "Crack requests: %d\n"
	        "Failed crack requests: %d\n"
	        "Successful crack requests: %d\n"
	        "Crypt requests: %d\n"
	        "crypt()/crypt_r() calls: %d\n",
		currentConN, totalConN,
	        crackReqNum, failCrackNum, succCrackNum,
		cryptReqNum, callNum);
       	fflush(stderr);
    }
}

//define a dynamic memory to store words
//REF: code of this memory is modified by A1 solution
typedef struct {
    int numWords;
    char** wordsArray;
} WordsMemory;

//REF: modified from A1 solution
WordsMemory add_word(WordsMemory words, char* word) {
    char* wordCpy;
    wordCpy = strdup(word);
    words.wordsArray = realloc(words.wordsArray, 
	    sizeof(char*) * (words.numWords + 1));
    words.wordsArray[words.numWords] = wordCpy;
    words.numWords++;
    return words;
}

//REF: modified by A1 solution
WordsMemory save_valid_words(FILE* file, char* dict) {
    WordsMemory validWords;
    validWords.numWords = 0;
    validWords.wordsArray = 0;
    char word[MAXINPUTWORDLEN];
    while (fgets(word, MAXINPUTWORDLEN, file)) {
        int len = strlen(word);
	if (len >= MINVALIDWORDLEN && word[len - 1] == NEWLINE) {
            word[len - 1] = STREND;
	    len--;
	}
	if (len <= MAXVALIDWORDLEN && len >= MINVALIDWORDLEN) {
	    validWords = add_word(validWords, word);
	}
    }
    
    return validWords;
}

//free dynamic memory
void free_words_memory(WordsMemory words) {
    for (int i = 0; i < words.numWords; i++) {
       	free(words.wordsArray[i]);
    }
    free(words.wordsArray);
}

//define func to stderr error messages and exit
void printf_wrong_dict(char* dict) {
    fprintf(stderr, 
	    "crackserver: unable to open dictionary file \"%s\"\n", 
	    dict);
    exit(2);
}

//emit message when no valid words
void printf_no_test_to_run() {
    fprintf(stderr, "crackserver: no plain text words to test\n");
    exit(3);
}

//to pass multiple params in one param when using multiple threads
//define struct to store them
struct ClientParams {
    char** pvalidWords;
    int pwordsNum;
    int pmaxConn;
    int pfD;
};

//definestruct to store params using in crack_thread
struct CrackParams {
    char** pvalidWords;
    int pwordsNum;
    int pthreadNum;
    char* pcipher;
    int pthreadOrder;
};

void* client_thread_wrapper(void* v);

void* crack_thread_wrapper(void* v);

//this is the function really works
void client_thread(char** validWords, int wordsNum, int maxConn, int fD) {
    int fD2 = dup(fD);
    FILE* to = fdopen(fD, "w");
    FILE* from = fdopen(fD2, "r");
    //REF LECTURE code
    char buffer[BUFFERLEN];
    char** fields;
    char* crt = "crypt";
    char* crk = "crack";
    char* error = ":invalid";
    char* fail = ":failed";
    char* buf;

    //using read_line to read from client
    while ( (buf = read_line(from)) != NULL) {	   
	//using split_by_char to split the whole sentence
        fields = split_by_char(buf, SPACEBAR, SUBSTRNUM);
	if (strcmp(fields[REQUESTYPELOC], crt) == 0) {
	    //count crypt request times
	    //using mutex to protect
	    pthread_mutex_lock(&cryptReqMutex);
	    cryptReqNum++;
	    pthread_mutex_unlock(&cryptReqMutex);
	    //ensure not to occur segfault
	    if (fields[REQUESTWORDLOC] != NULL &&
	        fields[SALTORTHREADLOC] != NULL) {
                int wordLen = strlen(fields[REQUESTWORDLOC]);
		int saltLen = strlen(fields[SALTORTHREADLOC]);
                if (wordLen != 0 && saltLen != 0) {
                    if (saltLen == SALTLEN) {
                        int validFlag = 0;
                        for (int i = 0; i < saltLen; i++) {
                             if(isdigit(fields[SALTORTHREADLOC][i]) || 
                                    isalpha(fields[SALTORTHREADLOC][i]) ||
                                        fields[SALTORTHREADLOC][i] == DOT ||
                                            fields[SALTORTHREADLOC][i] 
					        == SLANT) {
                                 validFlag++;   
                                }
                         }
                         if (validFlag == saltLen) {
                             strcpy(buffer, crypt(fields[REQUESTWORDLOC], 
			                fields[SALTORTHREADLOC]));
			     pthread_mutex_lock(&callMutex);
			     callNum++;
			     pthread_mutex_unlock(&callMutex);
                         } else {
                             strcpy(buffer, error);
                         }
                     } else {
                         strcpy(buffer, error);
                     }
                 } else {
                     strcpy(buffer, error);
                 }
            } else {
                strcpy(buffer, error);
            }  
	} else if (strcmp(fields[REQUESTYPELOC], crk) == 0) {
		   //count crack request times
		   //using mutex to protec
		   pthread_mutex_lock(&crackReqMutex);
		   crackReqNum++;
		   pthread_mutex_unlock(&crackReqMutex);
		   //ensure not to occur srgfault
	           if (fields[REQUESTWORDLOC] != NULL && 
		           fields[SALTORTHREADLOC] != NULL) {
                   int cipherLen = strlen(fields[REQUESTWORDLOC]);
		   int threadLen = strlen(fields[SALTORTHREADLOC]);
                   if (cipherLen == CIPHERLEN && threadLen > 0 && 
		           threadLen <3) {
                       int validFlag = 0;
		       //check all the args are valid
                       for (int i = 0; i < cipherLen; i++) {
                            if(isdigit(fields[REQUESTWORDLOC][i]) || 
                                    isalpha(fields[REQUESTWORDLOC][i]) ||
                                        fields[REQUESTWORDLOC][i] == DOT ||
                                            fields[REQUESTWORDLOC][i] 
					        == SLANT) {
                                validFlag++;
                         }
                       }
                       if (validFlag == cipherLen) {
                           validFlag = 0;
                           for (int i = 0; i < threadLen; i++) {
                                if (isdigit(fields[SALTORTHREADLOC][i])) {
                                validFlag++;
                            }
                           }
                           if (validFlag == threadLen) {
                               int threadNum = atoi(fields[SALTORTHREADLOC]);
                               if (threadNum <= MAXTHREADNUM &&  
			        threadNum >= MINTHREADNUM) {
		                   void* result;
				   char* res;
		                   pthread_t tid[threadNum];
		                   for (int j = 0; j < threadNum; j++) {
					//using dynamic struct to call 
					//the thread func
			                struct CrackParams* p3 = 
				            malloc(sizeof(struct CrackParams));
			                int order = j + 1;
			                p3->pwordsNum = wordsNum;
			                p3->pvalidWords = validWords;
			                p3->pthreadNum = threadNum;
			                p3->pcipher = fields[REQUESTWORDLOC];
			                p3->pthreadOrder = order;
			                pthread_create(&(tid[j]), NULL, 
						           crack_thread_wrapper
							       , p3);
				   }	
		                   for (int j = 0; j < threadNum; j++) {
					//get the return
			                pthread_join(tid[j], &result);
                                        res = (char*)result;
			                if (strcmp(res, fail) == 0) {
				            continue;
			                } else {	
				            strcpy(buffer, res);
				            break;
			                }
				   }
				   if (strcmp(res, fail) == 0) {
				       pthread_mutex_lock(&failCrackMutex);
				       failCrackNum++;
				       pthread_mutex_unlock(&failCrackMutex);
				   } else {
				       pthread_mutex_lock(&succCrackMutex);
				       succCrackNum++;
				       pthread_mutex_unlock(&succCrackMutex);
				   }
				   strcpy(buffer, res);
			       }else {
				  strcpy(buffer, error);
			       }
			   } else {
		               strcpy(buffer, error);
			   }
		       } else {
			   strcpy(buffer, error);
		       }
		   } else {
		      strcpy(buffer, error);
		   }
		   } else{
                       strcpy(buffer, error);
		   }
	} else {
            strcpy(buffer, error);
	}
    fprintf(to, "%s\n", buffer);
    fflush(to);
    }
    
    if (maxConn == 0) {
        fflush(stdout);
        fclose(to);
        fclose(from);
        close(fD);
    } else {
        pthread_mutex_lock(&conNmutex);
        currentConN--;
        pthread_mutex_unlock(&conNmutex);
        pthread_cond_broadcast(&cond);
        fflush(stdout);
        fclose(to);
        fclose(from);
        close(fD);
    }
}

//this function is the real function works when crack ciphers
char* crack_thread(char** validWords, int wordsNum, int threadNum, 
        char* cipher, int threadOrder) { 
    int bigCrackTimes = wordsNum / threadNum;
    int smallCrackTimes = wordsNum % threadNum;
    int crackTimes;
    if ((threadOrder + 1) * bigCrackTimes > wordsNum) {
	crackTimes = smallCrackTimes + bigCrackTimes;
    } else {
	crackTimes = bigCrackTimes;
    } 
    int len = strlen(cipher);
    char* result = ":failed";
    if (len == CIPHERLEN) {
	char salt[2];
	salt[0] = cipher[0];
	salt[1] = cipher[1];
	for (int i = 0; i < crackTimes; i++) {
	    pthread_mutex_lock(&crackMutex);
	    int currentWord = i + bigCrackTimes * (threadOrder - 1);
	    callNum++;
	    char* currentCipher = crypt(validWords[currentWord], salt);
	    if (strcmp(currentCipher, cipher) == 0) { 
		pthread_mutex_unlock(&crackMutex);
		return validWords[currentWord];
	    }
	    pthread_mutex_unlock(&crackMutex);  
	}
    }
    return result;
}

//wrapper the client_thread function
void* client_thread_wrapper(void* v) {
    struct ClientParams* p = (struct ClientParams*)v;
    client_thread(p->pvalidWords, p->pwordsNum, p->pmaxConn, p->pfD);
    free(v);
    return NULL;
}

//wrapper the client_thread function
void* crack_thread_wrapper(void* v) {
    struct CrackParams* p = (struct CrackParams*)v;
    char* result = crack_thread(p->pvalidWords, p->pwordsNum, p->pthreadNum,
            p->pcipher, p->pthreadOrder);
    free(v);
    return (void*)result;
}

//stderr messages and exit when fail to listen
void fail_listen() {
    fprintf(stderr, 
            "crackserver: unable to open socket for listening\n");
    exit(4);
}

//REF this function is modified by the code in the LEC
int open_listen(char* port) {
    struct addrinfo* ai = 0;
    struct addrinfo hints;

    memset(&hints, 0, sizeof(struct addrinfo));
    hints.ai_family = AF_INET;   
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;  

    int err;
    if ((err = getaddrinfo(NULL, port, &hints, &ai))) {
        freeaddrinfo(ai);
        fail_listen();
    }

    int listenfd = socket(AF_INET, SOCK_STREAM, 0); 
    int optVal = 1;
    if (setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, 
	    &optVal, sizeof(int)) < 0) {
        fail_listen();
    }


    if (bind(listenfd, ai->ai_addr, sizeof(struct sockaddr)) < 0) {
        fail_listen();
    }
                                    
    if (listen(listenfd, 10) < 0) {  
        fail_listen();
    }

    //get the real portnum
    struct sockaddr_in ad;
    memset(&ad, 0, sizeof(struct sockaddr_in));
    socklen_t len = sizeof(struct sockaddr_in);
    getsockname(listenfd, (struct sockaddr*)&ad, &len);
    fprintf(stderr, "%u\n", ntohs(ad.sin_port));
    return listenfd;
}

//REF this function is modified by the code on the lecture
void process_connections(int fdServer, char** validWords, 
        int wordsNum, int maxConn) {
    int fd;
    struct sockaddr_in fromAddr;
    socklen_t fromAddrSize;
    while (1) {
        fromAddrSize = sizeof(struct sockaddr_in);
        if (maxConn == 0) {
            pthread_mutex_lock(&conNmutex);
            fd = accept(fdServer, (struct sockaddr*)&fromAddr, &fromAddrSize);
	    currentConN++;
	    totalConN++;
	    pthread_mutex_unlock(&conNmutex);
        } else {
            pthread_mutex_lock(&conNmutex);
            while (currentConN >= maxConn) {
                pthread_cond_wait(&cond, &conNmutex);
            }
            fd = accept(fdServer, (struct sockaddr*)&fromAddr, &fromAddrSize);
            currentConN++;
	    totalConN++;
            pthread_mutex_unlock(&conNmutex);
        }
        char hostname[NI_MAXHOST];
        int error = getnameinfo((struct sockaddr*)&fromAddr, 
                fromAddrSize, hostname, NI_MAXHOST, NULL, 0, 0);
        if (error) {
            fprintf(stderr, "Error getting hostname: %s\n", 
                    gai_strerror(error));
        }
	//using struct to pass multiple params
        struct ClientParams* p1 = malloc(sizeof(struct ClientParams));
	p1->pvalidWords = validWords;
	p1->pwordsNum = wordsNum;
	p1->pmaxConn = maxConn;
	p1->pfD = fd;
	pthread_t threadId;
	pthread_create(&threadId, NULL, client_thread_wrapper, p1);
	pthread_detach(threadId);
    }
}

//printf usage then exit
void printf_usage() {
    fprintf(stderr, "Usage: crackserver [--maxconn connections] " 
	    "[--port portnum] [--dictionary filename]\n");
    exit(1);
}

int main(int argc, char* argv[]) {
    char* cmdNameCnect = "--maxconn";
    char* cmdNamePort = "--port";
    char* cmdNameDict = "--dictionary";
    int maxconn = 0;
    int portNum;
    char* port = "0";
    char* dict = "/usr/share/dict/words";
    int dictLoc;
    int cnectC = 0;
    int portC = 0;
    int dictC = 0;
    //check commandline
    for (int i = 0; i < argc; i++) {	
        if (strcmp(argv[i], cmdNameCnect) == 0) {
	    if (argv[i+1] == NULL) {
		printf_usage();
	    }
	    int len = strlen(argv[i + 1]);
	    char* num = argv[i + 1];
	    for (int j = 0; j < len; j++) {
		if (isdigit(num[j])) {
                    continue;
		} else {
		    printf_usage();
		}
	    }
	    maxconn = atoi(argv[i + 1]);
            if (maxconn < 0) {
                printf_usage();
            }
	    cnectC++;
	    continue;
	}
	if (strcmp(argv[i], cmdNamePort) == 0) {
	    if (argv[i+1] == NULL) {
		printf_usage();
	    }
	    int len = strlen(argv[i + 1]);
            char* num = argv[i + 1];
	    for (int j = 0; j < len; j++) {
	        if (isdigit(num[j])) {
	            continue;
		} else {
		    printf_usage();
		}
	    }
	    portNum = atoi(argv[i + 1]);
	    port = argv[i + 1];
	    if (portNum < 1024 || portNum > 65535) {
		printf_usage();
	    }
	    portC++;
	    continue;
	}
	if (strcmp(argv[i], cmdNameDict) == 0) {
	    if (argv[i+1] == NULL) {
                printf_usage();
	    }
	    dictLoc = i + 1;
	    dictC++;
	    continue;
	}
    }
    if (argc != 1 + (cnectC + portC + dictC) * 2 || 
            cnectC > 1 || portC > 1 || dictC > 1) {
	printf_usage();
    }
    //store valid words
    WordsMemory validMemory;
    if (dictC == 0) {
        FILE* op = fopen(dict, "r");
        if (op == NULL) {
	    printf_wrong_dict(dict);
        }
        validMemory = save_valid_words(op, dict);
        fclose(op);
        if (validMemory.numWords < 1) {
	    printf_no_test_to_run();
        }
    } else {
	FILE* p = fopen(argv[dictLoc], "r");
        if (p == NULL) {
	    printf_wrong_dict(argv[dictLoc]);
        }
        validMemory = save_valid_words(p, argv[dictLoc]);
        fclose(p);
        if (validMemory.numWords < 1) {
	    printf_no_test_to_run();
	}
    }
    
    if (portC == 0 || portNum == 0) {
	port = "0";
    }

    int fdServer = open_listen(port);

    //init mutex and cond
    pthread_mutex_init(&crackMutex, NULL);
    pthread_mutex_init(&conNmutex, NULL);
    pthread_cond_init(&cond, NULL);
    pthread_mutex_init(&cryptReqMutex, NULL);
    pthread_mutex_init(&callMutex, NULL);
    pthread_mutex_init(&crackReqMutex, NULL);
    pthread_mutex_init(&failCrackMutex, NULL);
    pthread_mutex_init(&succCrackMutex, NULL);

    //init sigaction to handle the SIGHUP
    struct sigaction sa;
    sa.sa_handler = sighup_handler;
    sa.sa_flags = SA_RESTART | SA_SIGINFO;
    sigaction(SIGHUP, &sa, 0);

    //connect client
    process_connections(fdServer, validMemory.wordsArray,
	    validMemory.numWords, maxconn);

    //destroy the mutex and cond
    pthread_mutex_destroy(&crackMutex);
    pthread_mutex_destroy(&conNmutex);
    pthread_cond_destroy(&cond);
    pthread_mutex_destroy(&cryptReqMutex);
    pthread_mutex_destroy(&callMutex);
    pthread_mutex_destroy(&crackReqMutex);
    pthread_mutex_destroy(&failCrackMutex);
    pthread_mutex_destroy(&succCrackMutex);
    free_words_memory(validMemory);

    return 0;
}
