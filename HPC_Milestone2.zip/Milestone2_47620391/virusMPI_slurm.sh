#!/bin/bash
#SBATCH --job-name=topic
#SBATCH --nodes=1
#SBATCH --ntasks=2
#SBATCH --ntasks-per-node=2
#SBATCH --cpus-per-task=4
#SBATCH --time=0-00:15:00 # time (D-HH:MM)
#SBATCH --partition=cosc3500
#SBATCH --account=cosc3500
time mpiexec -n 2 -bind-to none ./virusMPI

