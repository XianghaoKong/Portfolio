#!/bin/bash
#SBATCH --job-name=topic
#SBATCH --partition=cosc
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=4
#SBATCH --time=0-00:15:00 # time (D-HH:MM)
#SBATCH --partition=cosc3500
#SBATCH --account=cosc3500
time ./virus

