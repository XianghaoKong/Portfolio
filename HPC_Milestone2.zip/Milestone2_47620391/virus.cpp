#include <iostream>
#include <vector>
#include <random>
#include <algorithm>
#include <iterator>
#include <chrono>  // Include for timing
// Class to represent each agent in the simulation
class Agent {
public:
    enum State : uint8_t { SUSCEPTIBLE, INFECTED, RECOVERED }; // Use uint8_t to reduce memory usage

    Agent(State state = SUSCEPTIBLE) : state(state), daysInfected(0) {}

    State getState() const { return state; }
    void setState(State newState) { state = newState; }

    int getDaysInfected() const { return daysInfected; }
    void incrementDaysInfected() { ++daysInfected; }
    void resetDaysInfected() { daysInfected = 0; }

private:
    State state;
    uint8_t daysInfected;  // Change daysInfected to uint8_t to reduce memory usage
};

// Class to manage the epidemic simulation
class EpidemicSimulation {
public:
    EpidemicSimulation(int population, int initialInfected);
    void step();  // Advance the simulation by one time step
    void printStatistics() const;

private:
    std::vector<Agent> agents;
    std::default_random_engine rng;
    std::uniform_real_distribution<double> dist{0.0, 1.0};
    std::vector<double> precomputedRandomNumbers;

    int susceptibleCount;
    int infectedCount;
    int recoveredCount;

    const double infectionRate = 0.2;  // Probability of infection given contact
    const double recoveryRate = 0.5;  // Probability of an infected agent recovering
    const double immunityLossRate = 0.01;  // Probability of a recovered agent losing immunity
    const int durationOfInfectiousness = 7;  // Number of days an agent is infectious

    void precomputeRandomNumbers(int count);
    void infectAgents();
    void recoverAgents();
    double calculateContactRate() const;
};

// Constructor to initialize the population and set initial infected agents
EpidemicSimulation::EpidemicSimulation(int population, int initialInfected)
    : agents(population, Agent(Agent::SUSCEPTIBLE)),
      rng(std::random_device{}()), susceptibleCount(population - initialInfected),
      infectedCount(initialInfected), recoveredCount(0) {
    std::uniform_int_distribution<int> dist(0, population - 1);
    for (int i = 0; i < initialInfected; ++i) {
        int index = dist(rng);
        if (agents[index].getState() != Agent::INFECTED) {
            agents[index].setState(Agent::INFECTED);
            susceptibleCount--;
            infectedCount++;
        }
    }
    precomputeRandomNumbers(agents.size() * 2);  // Precompute random numbers for infectAgents and recoverAgents
}

// Precompute random numbers to reduce runtime overhead
void EpidemicSimulation::precomputeRandomNumbers(int count) {
    precomputedRandomNumbers.resize(count);
    for (int i = 0; i < count; ++i) {
        precomputedRandomNumbers[i] = dist(rng);
    }
}

// Calculate the contact rate
double EpidemicSimulation::calculateContactRate() const {
    return (infectedCount > 1) ? (static_cast<double>(infectedCount) / (agents.size() - 1)) : 0.0;
}

// Advance the simulation by one time step
void EpidemicSimulation::step() {
    auto start = std::chrono::high_resolution_clock::now();
    infectAgents();
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    //std::cout << "Time taken for infectAgents: " << elapsed.count() << " seconds." << std::endl;

    start = std::chrono::high_resolution_clock::now();
    recoverAgents();
    end = std::chrono::high_resolution_clock::now();
    elapsed = end - start;
    //std::cout << "Time taken for recoverAgents: " << elapsed.count() << " seconds." << std::endl;
}

// Define how agents become infected based on contact rate and infection rate
void EpidemicSimulation::infectAgents() {
    double contactRate = calculateContactRate();
    for (size_t i = 0; i < agents.size(); ++i) {
        if (agents[i].getState() == Agent::SUSCEPTIBLE) {
            if (precomputedRandomNumbers[i * 2] < contactRate && precomputedRandomNumbers[i * 2 + 1] < infectionRate) {
                agents[i].setState(Agent::INFECTED);             
                infectedCount++;
                susceptibleCount--;
            }
        }
    }
}

// Define how infected agents recover or lose immunity
void EpidemicSimulation::recoverAgents() {
    for (size_t i = 0; i < agents.size(); ++i) {
        if (agents[i].getState() == Agent::INFECTED) {
            agents[i].incrementDaysInfected();
            if (agents[i].getDaysInfected() >= durationOfInfectiousness) {
                if (precomputedRandomNumbers[i * 2] < recoveryRate) {
                    agents[i].setState(Agent::RECOVERED);
                    agents[i].resetDaysInfected();
                    infectedCount--;
                    recoveredCount++;
                } else {
                    agents[i].setState(Agent::SUSCEPTIBLE);
                    agents[i].resetDaysInfected();
                    infectedCount--;
                    susceptibleCount++;
                }
            }
        } else if (agents[i].getState() == Agent::RECOVERED && precomputedRandomNumbers[i * 2 + 1] < immunityLossRate) {
            agents[i].setState(Agent::SUSCEPTIBLE);
            recoveredCount--;
            susceptibleCount++;
        }
    }
}

// Print statistics of the current simulation state
void EpidemicSimulation::printStatistics() const {
    auto start = std::chrono::high_resolution_clock::now();
    std::cout << "Susceptible: " << susceptibleCount << "\n";
    std::cout << "Infected: " << infectedCount << "\n";
    std::cout << "Recovered: " << recoveredCount << "\n";
    std::cout << "Contact Rate: " << calculateContactRate() << "\n";
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    //std::cout << "Time taken for printStatistics: " << elapsed.count() << " seconds." << std::endl;
}

// Main function to run the simulation
int main() {
    const int population = 100000;
    const int initialInfected = 10000;
    EpidemicSimulation sim(population, initialInfected);
    std::cout << "Initial State:\n";
    sim.printStatistics();
    for (int day = 0; day < 1000; ++day) {
        auto start = std::chrono::high_resolution_clock::now();
        sim.step();
        auto end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> elapsed = end - start;
        std::cout << "Time taken for day " << day + 1 << ": " << elapsed.count() << " seconds." << std::endl;
        std::cout << "Day " << day + 1 << ":\n";
        sim.printStatistics();
    }

    return 0;
}