#include <iostream>
#include <vector>
#include <random>
#include <algorithm>
#include <iterator>
#include <omp.h>  
#include <chrono> 

#ifdef _OPENMP
#include <omp.h>
#endif

// Class to represent each agent in the simulation
class Agent {
public:
    enum State : uint8_t { SUSCEPTIBLE, INFECTED, RECOVERED }; // Use uint8_t to reduce memory usage

    Agent(State state = SUSCEPTIBLE) : state(state), daysInfected(0) {}

    State getState() const { return state; }
    void setState(State newState) { state = newState; }

    int getDaysInfected() const { return daysInfected; }
    void incrementDaysInfected() { ++daysInfected; }
    void resetDaysInfected() { daysInfected = 0; }

private:
    State state;
    uint8_t daysInfected;  // Change `daysInfected` to uint8_t to reduce memory usage
};

// Class to manage the epidemic simulation
class EpidemicSimulation {
public:
    EpidemicSimulation(int population, int initialInfected);
    void step();  
    void printStatistics() const;

private:
    std::vector<Agent> agents;
    std::default_random_engine rng;
    std::uniform_real_distribution<double> dist{0.0, 1.0};
    std::vector<double> precomputedRandomNumbers;

    int susceptibleCount;
    int infectedCount;
    int recoveredCount;

    const double infectionRate = 0.2;  // Probability of infection given contact
    const double recoveryRate = 0.5;  // Probability of an infected agent recovering
    const double immunityLossRate = 0.01;  // Probability of a recovered agent losing immunity
    const int durationOfInfectiousness = 7;  // Number of days an agent is infectious

    void precomputeRandomNumbers(int count);
    void infectAndRecoverAgents();
    double calculateContactRate() const;
};

// Constructor to initialize the population and set initial infected agents
EpidemicSimulation::EpidemicSimulation(int population, int initialInfected)
    : agents(population, Agent(Agent::SUSCEPTIBLE)),
      rng(std::random_device{}()), susceptibleCount(population - initialInfected),
      infectedCount(initialInfected), recoveredCount(0) {
    std::uniform_int_distribution<int> dist(0, population - 1);
    for (int i = 0; i < initialInfected; ++i) {
        int index = dist(rng);
        if (agents[index].getState() != Agent::INFECTED) {
            agents[index].setState(Agent::INFECTED);
            susceptibleCount--;
            infectedCount++;
        }
    }
    precomputeRandomNumbers(agents.size() * 2);  // Precompute random numbers for infectAndRecoverAgents
}

// Precompute random numbers to reduce runtime overhead
void EpidemicSimulation::precomputeRandomNumbers(int count) {
    precomputedRandomNumbers.resize(count);
    #pragma omp parallel
    {
        std::default_random_engine local_rng(std::random_device{}());
        std::uniform_real_distribution<double> local_dist(0.0, 1.0);
        #pragma omp for
        for (int i = 0; i < count; ++i) {
            precomputedRandomNumbers[i] = local_dist(local_rng);
        }
    }
}

// Calculate the contact rate
double EpidemicSimulation::calculateContactRate() const {
    return (infectedCount > 1) ? (static_cast<double>(infectedCount) / (agents.size() - 1)) : 0.0;
}

// Advance the simulation by one time step
void EpidemicSimulation::step() {
    infectAndRecoverAgents();
}

// Define how agents become infected or recover based on contact rate and infection/recovery rates
void EpidemicSimulation::infectAndRecoverAgents() {
    double contactRate = calculateContactRate();

    int localInfectedCount = 0;
    int localRecoveredCount = 0;
    int localSusceptibleCount = 0;

    #pragma omp parallel for reduction(+:localInfectedCount, localRecoveredCount, localSusceptibleCount)
    for (size_t i = 0; i < agents.size(); ++i) {
        if (agents[i].getState() == Agent::SUSCEPTIBLE) {
            // Handle infection process for susceptible agents
            if (precomputedRandomNumbers[i * 2] < contactRate && precomputedRandomNumbers[i * 2 + 1] < infectionRate) {
                agents[i].setState(Agent::INFECTED);
                localInfectedCount++;
                localSusceptibleCount--;
            }
        } else if (agents[i].getState() == Agent::INFECTED) {
            // Handle recovery process for infected agents
            agents[i].incrementDaysInfected();
            if (agents[i].getDaysInfected() >= durationOfInfectiousness) {
                if (precomputedRandomNumbers[i * 2] < recoveryRate) {
                    agents[i].setState(Agent::RECOVERED);
                    agents[i].resetDaysInfected();
                    localInfectedCount--;
                    localRecoveredCount++;
                } else {
                    agents[i].setState(Agent::SUSCEPTIBLE);
                    agents[i].resetDaysInfected();
                    localInfectedCount--;
                    localSusceptibleCount++;
                }
            }
        } else if (agents[i].getState() == Agent::RECOVERED) {
            // Handle immunity loss for recovered agents
            if (precomputedRandomNumbers[i * 2 + 1] < immunityLossRate) {
                agents[i].setState(Agent::SUSCEPTIBLE);
                localRecoveredCount--;
                localSusceptibleCount++;
            }
        }
    }

    infectedCount += localInfectedCount;
    recoveredCount += localRecoveredCount;
    susceptibleCount += localSusceptibleCount;
}

// Print statistics of the current simulation state
void EpidemicSimulation::printStatistics() const {
    auto start = std::chrono::high_resolution_clock::now();
    std::cout << "Susceptible: " << susceptibleCount << "\n";
    std::cout << "Infected: " << infectedCount << "\n";
    std::cout << "Recovered: " << recoveredCount << "\n";
    //std::cout << "Contact Rate: " << calculateContactRate() << "\n";
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    //std::cout << "Time taken for printStatistics: " << elapsed.count() << " seconds." << std::endl;
}

// Main function to run the simulation
int main() {
    const int population = 200000000;
    const int initialInfected = 10000000;
    EpidemicSimulation sim(population, initialInfected);

    #ifdef _OPENMP
    std::cout << "Running with " << omp_get_max_threads() << " threads on CPU." << std::endl;
    #else
    std::cout << "Running without OpenMP support." << std::endl;
    #endif

    std::cout << "Initial State:\n";
    sim.printStatistics();

    for (int day = 0; day < 1000; ++day) {
        auto start = std::chrono::high_resolution_clock::now();
        sim.step();
        auto end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> elapsed = end - start;
        std::cout << "Time taken for day " << day + 1 << ": " << elapsed.count() << " seconds." << std::endl;
        std::cout << "Day " << day + 1 << ":\n";
        sim.printStatistics();
    }

    return 0;
}
