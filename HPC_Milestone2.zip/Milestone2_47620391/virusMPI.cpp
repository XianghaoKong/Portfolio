#include <iostream>
#include <vector>
#include <random>
#include <algorithm>
#include <iterator>
#include <omp.h>  
#include <chrono>  
#include <mpi.h>  

#ifdef _OPENMP
#include <omp.h>
#endif

// Class to represent each agent in the simulation
class Agent {
public:
    enum State : uint8_t { SUSCEPTIBLE, INFECTED, RECOVERED }; // Use uint8_t to reduce memory usage

    Agent(State state = SUSCEPTIBLE) : state(state), daysInfected(0) {}

    State getState() const { return state; }
    void setState(State newState) { state = newState; }

    int getDaysInfected() const { return daysInfected; }
    void incrementDaysInfected() { ++daysInfected; }
    void resetDaysInfected() { daysInfected = 0; }

private:
    State state;
    uint8_t daysInfected;  // Change `daysInfected` to uint8_t to reduce memory usage
};

// Class to manage the epidemic simulation
class EpidemicSimulation {
public:
    EpidemicSimulation(int population, int initialInfected);
    void step();  // Advance the simulation by one time step
    void printStatistics() const;

    int getSusceptibleCount() const { return susceptibleCount; }
    int getInfectedCount() const { return infectedCount; }
    int getRecoveredCount() const { return recoveredCount; }

private:
    std::vector<Agent> agents;
    std::default_random_engine rng;
    std::uniform_real_distribution<double> dist{0.0, 1.0};
    std::vector<double> precomputedRandomNumbers;

    int susceptibleCount;
    int infectedCount;
    int recoveredCount;

    const double infectionRate = 0.2;  // Probability of infection given contact
    const double recoveryRate = 0.5;  // Probability of an infected agent recovering
    const double immunityLossRate = 0.01;  // Probability of a recovered agent losing immunity
    const int durationOfInfectiousness = 7;  // Number of days an agent is infectious

    void precomputeRandomNumbers(int count);
    void infectAndRecoverAgents();
    double calculateContactRate() const;
};

// Constructor to initialize the population and set initial infected agents
EpidemicSimulation::EpidemicSimulation(int population, int initialInfected)
    : agents(population, Agent(Agent::SUSCEPTIBLE)),
      rng(std::random_device{}()), susceptibleCount(population - initialInfected),
      infectedCount(initialInfected), recoveredCount(0) {
    std::uniform_int_distribution<int> dist(0, population - 1);
    for (int i = 0; i < initialInfected; ++i) {
        int index = dist(rng);
        if (agents[index].getState() != Agent::INFECTED) {
            agents[index].setState(Agent::INFECTED);
            susceptibleCount--;
            infectedCount++;
        }
    }
    precomputeRandomNumbers(agents.size() * 2);  // Precompute random numbers for infectAndRecoverAgents
}

// Precompute random numbers to reduce runtime overhead
void EpidemicSimulation::precomputeRandomNumbers(int count) {
    precomputedRandomNumbers.resize(count);
    #pragma omp parallel
    {
        std::default_random_engine local_rng(std::random_device{}());
        std::uniform_real_distribution<double> local_dist(0.0, 1.0);
        #pragma omp for
        for (int i = 0; i < count; ++i) {
            precomputedRandomNumbers[i] = local_dist(local_rng);
        }
    }
}

// Calculate the contact rate
double EpidemicSimulation::calculateContactRate() const {
    return (infectedCount > 1) ? (static_cast<double>(infectedCount) / (agents.size() - 1)) : 0.0;
}

// Advance the simulation by one time step
void EpidemicSimulation::step() {
    infectAndRecoverAgents();
}

// Define how agents become infected or recover based on contact rate and infection/recovery rates
void EpidemicSimulation::infectAndRecoverAgents() {
    double contactRate = calculateContactRate();

    int localInfectedCount = 0;
    int localRecoveredCount = 0;
    int localSusceptibleCount = 0;

    #pragma omp parallel for reduction(+:localInfectedCount, localRecoveredCount, localSusceptibleCount)
    for (size_t i = 0; i < agents.size(); ++i) {
        if (agents[i].getState() == Agent::SUSCEPTIBLE) {
            // Handle infection process for susceptible agents
            if (precomputedRandomNumbers[i * 2] < contactRate && precomputedRandomNumbers[i * 2 + 1] < infectionRate) {
                agents[i].setState(Agent::INFECTED);
                localInfectedCount++;
                localSusceptibleCount--;
            }
        } else if (agents[i].getState() == Agent::INFECTED) {
            // Handle recovery process for infected agents
            agents[i].incrementDaysInfected();
            if (agents[i].getDaysInfected() >= durationOfInfectiousness) {
                if (precomputedRandomNumbers[i * 2] < recoveryRate) {
                    agents[i].setState(Agent::RECOVERED);
                    agents[i].resetDaysInfected();
                    localInfectedCount--;
                    localRecoveredCount++;
                } else {
                    agents[i].setState(Agent::SUSCEPTIBLE);
                    agents[i].resetDaysInfected();
                    localInfectedCount--;
                    localSusceptibleCount++;
                }
            }
        } else if (agents[i].getState() == Agent::RECOVERED) {
            // Handle immunity loss for recovered agents
            if (precomputedRandomNumbers[i * 2 + 1] < immunityLossRate) {
                agents[i].setState(Agent::SUSCEPTIBLE);
                localRecoveredCount--;
                localSusceptibleCount++;
            }
        }
    }

    infectedCount += localInfectedCount;
    recoveredCount += localRecoveredCount;
    susceptibleCount += localSusceptibleCount;
}

// Print statistics of the current simulation state
void EpidemicSimulation::printStatistics() const {
    auto start = std::chrono::high_resolution_clock::now();
    std::cout << "Susceptible: " << susceptibleCount << "\n";
    std::cout << "Infected: " << infectedCount << "\n";
    std::cout << "Recovered: " << recoveredCount << "\n";
    std::cout << "Contact Rate: " << calculateContactRate() << "\n";
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    std::cout << "Time taken for printStatistics: " << elapsed.count() << " seconds." << std::endl;
}

// Main function to run the simulation
int main(int argc, char* argv[]) {
    MPI_Init(&argc, &argv);

    int world_size;
    int world_rank;
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);

    if (world_size != 2) {
        std::cerr << "This simulation requires exactly 2 processes." << std::endl;
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    const int population = 500000000;
    const int initialInfected = 10000000;
    const int local_population = population / world_size;
    const int local_initialInfected = initialInfected / world_size;

    EpidemicSimulation sim(local_population, local_initialInfected);

    #ifdef _OPENMP
    if (world_rank == 0) {
        std::cout << "Running with " << omp_get_max_threads() << " threads on CPU." << std::endl;
    }
    #else
    if (world_rank == 0) {
        std::cout << "Running without OpenMP support." << std::endl;
    }
    #endif

    for (int day = 0; day < 1000; ++day) {
        auto day_start = std::chrono::high_resolution_clock::now();
        sim.step();

        // Gather statistics from both processes
        auto mpi_reduce_total_start = std::chrono::high_resolution_clock::now();
        int localSusceptible, localInfected, localRecovered;
        localSusceptible = sim.getSusceptibleCount();
        localInfected = sim.getInfectedCount();
        localRecovered = sim.getRecoveredCount();

        int globalSusceptible, globalInfected, globalRecovered;
        MPI_Reduce(&localSusceptible, &globalSusceptible, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
        MPI_Reduce(&localInfected, &globalInfected, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
        MPI_Reduce(&localRecovered, &globalRecovered, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
        auto mpi_reduce_total_end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> mpi_reduce_total_elapsed = mpi_reduce_total_end - mpi_reduce_total_start;
        if (world_rank == 0) {
            std::cout << "Total MPI_Reduce time taken: " << mpi_reduce_total_elapsed.count() << " seconds." << std::endl;
        }

        auto day_end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> day_elapsed = day_end - day_start;

        if (world_rank == 0) {
            std::cout << "Day " << day + 1 << ":\n";
            std::cout << "Susceptible: " << globalSusceptible << "\n";
            std::cout << "Infected: " << globalInfected << "\n";
            std::cout << "Recovered: " << globalRecovered << "\n";
            std::cout << "Time taken for day " << day + 1 << ": " << day_elapsed.count() << " seconds." << std::endl;
        }
    }

    MPI_Finalize();
    return 0;
}
