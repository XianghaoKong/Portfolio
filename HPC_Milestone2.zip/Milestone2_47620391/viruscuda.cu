#include <iostream>
#include <curand_kernel.h>
#include <chrono>

#define GRID_SIZE_X 2000
#define GRID_SIZE_Y 2000
#define INDIVIDUALS_PER_CELL 50

struct Agent {
    enum State : uint8_t { SUSCEPTIBLE, INFECTED, RECOVERED };
    State state;
    uint8_t daysInfected;
};

__global__ void epidemicSimulationStep(Agent* agents, curandState* states, int* counts, 
                                       double infectionRate, double contactRate, 
                                       double recoveryRate, double immunityLossRate, 
                                       int durationOfInfectiousness, bool initialize) {
    int idxX = blockIdx.x * blockDim.x + threadIdx.x;
    int idxY = blockIdx.y * blockDim.y + threadIdx.y;

    if (idxX < GRID_SIZE_X && idxY < GRID_SIZE_Y) {
        int cellIndex = idxY * GRID_SIZE_X + idxX;
        Agent* cellAgents = &agents[cellIndex * INDIVIDUALS_PER_CELL];
        curandState localState = states[cellIndex];

        __shared__ int localCounts[3];
        if (threadIdx.x == 0 && threadIdx.y == 0) {
            localCounts[0] = 0;
            localCounts[1] = 0;
            localCounts[2] = 0;
        }
        __syncthreads();

        // Initialization phase
        if (initialize) {
            for (int i = 0; i < INDIVIDUALS_PER_CELL; ++i) {
                cellAgents[i].state = Agent::SUSCEPTIBLE;
                cellAgents[i].daysInfected = 0;
            }
            curand_init(1234, cellIndex, 0, &localState);
        } else {
            // Update individual states
            for (int i = 0; i < INDIVIDUALS_PER_CELL; ++i) {
                Agent& agent = cellAgents[i];
                if (agent.state == Agent::SUSCEPTIBLE) {
                    double randVal = curand_uniform(&localState);
                    if (randVal < contactRate && randVal < infectionRate) {
                        agent.state = Agent::INFECTED;
                        atomicAdd(&localCounts[1], 1);
                        atomicSub(&localCounts[0], 1);
                    }
                } else if (agent.state == Agent::INFECTED) {
                    agent.daysInfected++;
                    if (agent.daysInfected >= durationOfInfectiousness) {
                        double randVal = curand_uniform(&localState);
                        if (randVal < recoveryRate) {
                            agent.state = Agent::RECOVERED;
                            agent.daysInfected = 0;
                            atomicAdd(&localCounts[2], 1);
                            atomicSub(&localCounts[1], 1);
                        } else {
                            agent.state = Agent::SUSCEPTIBLE;
                            agent.daysInfected = 0;
                            atomicAdd(&localCounts[0], 1);
                            atomicSub(&localCounts[1], 1);
                        }
                    }
                } else if (agent.state == Agent::RECOVERED) {
                    double randVal = curand_uniform(&localState);
                    if (randVal < immunityLossRate) {
                        agent.state = Agent::SUSCEPTIBLE;
                        atomicAdd(&localCounts[0], 1);
                        atomicSub(&localCounts[2], 1);
                    }
                }
            }
        }

        __syncthreads();
        if (threadIdx.x == 0 && threadIdx.y == 0) {
            atomicAdd(&counts[0], localCounts[0]);
            atomicAdd(&counts[1], localCounts[1]);
            atomicAdd(&counts[2], localCounts[2]);
        }

        states[cellIndex] = localState;
    }
}

void initializeInfectedAgents(Agent* agents, int population, int initialInfectedCount) {
    for (int i = 0; i < initialInfectedCount; ++i) {
        int randomIndex = rand() % population;
        agents[randomIndex].state = Agent::INFECTED;
    }
}

int main() {
    const int population = GRID_SIZE_X * GRID_SIZE_Y * INDIVIDUALS_PER_CELL;
    const double infectionRate = 0.2;
    const double recoveryRate = 0.5;
    const double immunityLossRate = 0.01;
    const int durationOfInfectiousness = 7;
    const int initialInfectedCount = 10000000;

    Agent* d_agents;
    curandState* d_states;
    int* d_counts;
    int h_counts[3] = {population - initialInfectedCount, initialInfectedCount, 0};

    cudaMalloc(&d_agents, population * sizeof(Agent));
    cudaMalloc(&d_states, GRID_SIZE_X * GRID_SIZE_Y * sizeof(curandState));
    cudaMalloc(&d_counts, 3 * sizeof(int));

    cudaMemcpy(d_counts, h_counts, 3 * sizeof(int), cudaMemcpyHostToDevice);

    dim3 blockSize(32, 32);
    dim3 numBlocks((GRID_SIZE_X + blockSize.x - 1) / blockSize.x, 
                   (GRID_SIZE_Y + blockSize.y - 1) / blockSize.y);

    // Initialization phase
    cudaStream_t stream;
    cudaStreamCreate(&stream);
    epidemicSimulationStep<<<numBlocks, blockSize, 0, stream>>>(d_agents, d_states, d_counts, 
                                                                infectionRate, 0.0, 
                                                                recoveryRate, immunityLossRate, 
                                                                durationOfInfectiousness, 
                                                                true);
    cudaStreamSynchronize(stream);

    // Randomly assign initial infected individuals
    Agent* h_agents = new Agent[population];
    cudaMemcpy(h_agents, d_agents, population * sizeof(Agent), cudaMemcpyDeviceToHost);
    initializeInfectedAgents(h_agents, population, initialInfectedCount);
    cudaMemcpy(d_agents, h_agents, population * sizeof(Agent), cudaMemcpyHostToDevice);
    delete[] h_agents;

    // Simulate for 1000 days
    for (int day = 0; day < 1000; ++day) {
        // Calculate contact rate
        cudaMemcpyAsync(h_counts, d_counts, 3 * sizeof(int), cudaMemcpyDeviceToHost, stream);
        cudaStreamSynchronize(stream);
        double contactRate = static_cast<double>(h_counts[1]) / population;

        auto start = std::chrono::high_resolution_clock::now();
        epidemicSimulationStep<<<numBlocks, blockSize, 0, stream>>>(d_agents, d_states, d_counts, 
                                                                    infectionRate, contactRate, 
                                                                    recoveryRate, immunityLossRate, 
                                                                    durationOfInfectiousness, 
                                                                    false);
        cudaStreamSynchronize(stream);
        auto end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> elapsed = end - start;
        std::cout << "Time taken for day " << day + 1 << ": " << elapsed.count() << " seconds." << std::endl;

        std::cout << "Day " << day + 1 << ":\n";
        std::cout << "Susceptible: " << h_counts[0] << "\n";
        std::cout << "Infected: " << h_counts[1] << "\n";
        std::cout << "Recovered: " << h_counts[2] << "\n";
    }

    cudaStreamDestroy(stream);
    cudaFree(d_agents);
    cudaFree(d_states);
    cudaFree(d_counts);

    return 0;
}
