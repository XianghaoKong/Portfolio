from pathlib import Path
import math
import csv


# Evaluate Baseline1, Baseline2 and Model_C outputs.

# Set the main folder path.
BASE_DIR = Path(__file__).resolve().parent

# Set the relevance judgement folder path.
JUDGEMENT_DIR = BASE_DIR / "Relevant_Judgements"
# Set the output folder path.
OUTPUT_DIR = BASE_DIR / "ModelOutputs"
# Set the evaluation result file path.
EVAL_OUTPUT_FILE = OUTPUT_DIR / "Evaluation_Results.csv"

# List the models evaluated by the script.
MODELS = ["Baseline1", "Baseline2", "ModelC"]


# Read relevant document IDs from one judgement file.
def read_relevance_judgements(judgement_file):
    relevant_docs = set()

    with open(judgement_file, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            parts = line.strip().split()

            if len(parts) < 3:
                continue

            doc_id = parts[1]
            relevance = parts[2]

            if relevance == "1":
                relevant_docs.add(doc_id)

    return relevant_docs


# Read one ranking output file.
def read_ranking_file(ranking_file):
    ranked_doc_ids = []

    with open(ranking_file, "r", encoding="utf-8", errors="ignore") as f:
        first_line = True

        for line in f:
            line = line.strip()

            if not line:
                continue

            if first_line:
                first_line = False
                if line.lower().startswith("doc_id"):
                    continue

            parts = line.split()

            if len(parts) < 2:
                continue

            doc_id = parts[0]
            ranked_doc_ids.append(doc_id)

    return ranked_doc_ids


# Calculate Average Precision for one ranked list.
def average_precision(ranked_doc_ids, relevant_docs):
    if len(relevant_docs) == 0:
        return 0.0

    relevant_retrieved = 0
    precision_sum = 0.0

    for rank, doc_id in enumerate(ranked_doc_ids, start=1):
        if doc_id in relevant_docs:
            relevant_retrieved += 1
            precision_at_rank = relevant_retrieved / rank
            precision_sum += precision_at_rank

    return precision_sum / len(relevant_docs)


# Calculate Precision at rank 10.
def precision_at_10(ranked_doc_ids, relevant_docs):
    top_10 = ranked_doc_ids[:10]

    if len(top_10) == 0:
        return 0.0

    relevant_count = sum(1 for doc_id in top_10 if doc_id in relevant_docs)

    return relevant_count / 10


# Calculate DCG at rank 10.
def dcg_at_10(ranked_doc_ids, relevant_docs):
    top_10 = ranked_doc_ids[:10]

    dcg = 0.0

    for i, doc_id in enumerate(top_10, start=1):
        rel_i = 1 if doc_id in relevant_docs else 0

        if i == 1:
            dcg += rel_i
        else:
            dcg += rel_i / math.log2(i)

    return dcg


# Evaluate all model output files against relevance judgements.
def evaluate_models():
    results = []

    topic_numbers = range(101, 151)

    for topic_num in topic_numbers:
        topic_id = f"R{topic_num}"
        judgement_file = JUDGEMENT_DIR / f"Dataset{topic_num}.txt"

        if not judgement_file.exists():
            print(f"Missing judgement file: {judgement_file}")
            continue

        relevant_docs = read_relevance_judgements(judgement_file)

        for model_name in MODELS:
            ranking_file = OUTPUT_DIR / f"{model_name}_{topic_id}_Ranking.dat"

            if not ranking_file.exists():
                print(f"Missing ranking file: {ranking_file}")
                continue

            ranked_doc_ids = read_ranking_file(ranking_file)

            ap = average_precision(ranked_doc_ids, relevant_docs)
            p10 = precision_at_10(ranked_doc_ids, relevant_docs)
            dcg10 = dcg_at_10(ranked_doc_ids, relevant_docs)

            results.append({
                "Topic": topic_id,
                "Model": model_name,
                "AveragePrecision": ap,
                "Precision@10": p10,
                "DCG@10": dcg10
            })

    return results


# Save evaluation results to a CSV file.
def write_results_to_csv(results):
    with open(EVAL_OUTPUT_FILE, "w", newline="", encoding="utf-8") as f:
        fieldnames = ["Topic", "Model", "AveragePrecision", "Precision@10", "DCG@10"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)

        writer.writeheader()

        for row in results:
            writer.writerow(row)


# Print the average evaluation results.
def print_summary(results):
    print("Evaluation Summary")

    for model_name in MODELS:
        model_rows = [row for row in results if row["Model"] == model_name]

        if not model_rows:
            continue

        mean_ap = sum(row["AveragePrecision"] for row in model_rows) / len(model_rows)
        mean_p10 = sum(row["Precision@10"] for row in model_rows) / len(model_rows)
        mean_dcg10 = sum(row["DCG@10"] for row in model_rows) / len(model_rows)

        print(f"\n{model_name}")
        print(f"MAP:          {mean_ap:.4f}")
        print(f"Average P@10: {mean_p10:.4f}")
        print(f"Average DCG@10: {mean_dcg10:.4f}")


# Run the program.
def main():
    results = evaluate_models()
    write_results_to_csv(results)
    print_summary(results)

    print(f"Results saved to: {EVAL_OUTPUT_FILE}")


if __name__ == "__main__":
    main()
