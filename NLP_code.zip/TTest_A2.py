from pathlib import Path
import csv
import math
from collections import defaultdict


# Run paired t-tests on the evaluation results.

# Set the main folder path.
BASE_DIR = Path(__file__).resolve().parent
# Set the output folder path.
OUTPUT_DIR = BASE_DIR / "ModelOutputs"

# Set the input evaluation file for t-tests.
EVAL_FILE = OUTPUT_DIR / "Evaluation_Results.csv"
# Set the t-test output file path.
TTEST_OUTPUT_FILE = OUTPUT_DIR / "TTest_Results.csv"


# Read evaluation results for significance testing.
def read_evaluation_results(eval_file):
    results = defaultdict(lambda: defaultdict(dict))

    with open(eval_file, "r", encoding="utf-8", errors="ignore") as f:
        reader = csv.DictReader(f)

        for row in reader:
            topic = row["Topic"]
            model = row["Model"]

            results["AveragePrecision"][model][topic] = float(row["AveragePrecision"])
            results["Precision@10"][model][topic] = float(row["Precision@10"])
            results["DCG@10"][model][topic] = float(row["DCG@10"])

    return results


# Calculate the probability density of the t distribution.
def t_pdf(x, df):
    numerator = math.gamma((df + 1) / 2)
    denominator = math.sqrt(df * math.pi) * math.gamma(df / 2)
    return (numerator / denominator) * (1 + (x * x) / df) ** (-(df + 1) / 2)


# Calculate the cumulative probability of the t distribution.
def t_cdf(x, df):
    if x == 0:
        return 0.5

    if x < 0:
        return 1 - t_cdf(-x, df)

    if x > 30:
        return 1.0

    n_steps = 10000
    if n_steps % 2 == 1:
        n_steps += 1

    h = x / n_steps
    total = t_pdf(0, df) + t_pdf(x, df)

    for i in range(1, n_steps):
        current_x = i * h
        coefficient = 4 if i % 2 == 1 else 2
        total += coefficient * t_pdf(current_x, df)

    integral = total * h / 3

    return 0.5 + integral


# Run a paired t-test between Model_C and one baseline.
def paired_t_test(model_c_scores, baseline_scores):
    if len(model_c_scores) != len(baseline_scores):
        raise ValueError("The two score lists must have the same length.")

    n = len(model_c_scores)

    if n < 2:
        return n, 0.0, 0.0, 1.0

    differences = [
        model_c_scores[i] - baseline_scores[i]
        for i in range(n)
    ]

    mean_diff = sum(differences) / n

    squared_diff_sum = sum((d - mean_diff) ** 2 for d in differences)
    sample_variance = squared_diff_sum / (n - 1)
    sample_std = math.sqrt(sample_variance)

    if sample_std == 0:
        if mean_diff == 0:
            return n, mean_diff, 0.0, 1.0
        return n, mean_diff, float("inf"), 0.0

    t_statistic = mean_diff / (sample_std / math.sqrt(n))
    df = n - 1

    cdf_value = t_cdf(abs(t_statistic), df)
    p_value = 2 * (1 - cdf_value)
    p_value = max(0.0, min(1.0, p_value))

    return n, mean_diff, t_statistic, p_value


# Run paired t-tests for all metrics and baselines.
def run_t_tests():
    results = read_evaluation_results(EVAL_FILE)

    comparisons = [
        ("ModelC", "Baseline1"),
        ("ModelC", "Baseline2")
    ]

    metrics = [
        "AveragePrecision",
        "Precision@10",
        "DCG@10"
    ]

    output_rows = []

    print("Paired t-test results")

    for metric in metrics:
        print(f"\nMetric: {metric}")

        for model_c_name, baseline_name in comparisons:
            model_c_topic_scores = results[metric][model_c_name]
            baseline_topic_scores = results[metric][baseline_name]

            common_topics = sorted(
                set(model_c_topic_scores.keys()) &
                set(baseline_topic_scores.keys())
            )

            model_c_scores = [model_c_topic_scores[t] for t in common_topics]
            baseline_scores = [baseline_topic_scores[t] for t in common_topics]

            n, mean_diff, t_stat, p_value = paired_t_test(model_c_scores, baseline_scores)

            significant = "Yes" if p_value < 0.05 else "No"

            print(
                f"{model_c_name} vs {baseline_name}: "
                f"n={n}, mean_diff={mean_diff:.6f}, "
                f"t={t_stat:.6f}, p={p_value:.6f}, significant={significant}"
            )

            output_rows.append({
                "Metric": metric,
                "Comparison": f"{model_c_name} vs {baseline_name}",
                "N": n,
                "Mean_Difference": mean_diff,
                "T_statistic": t_stat,
                "P_value_two_tailed": p_value,
                "Significant_at_0.05": significant
            })

    with open(TTEST_OUTPUT_FILE, "w", newline="", encoding="utf-8") as f:
        fieldnames = [
            "Metric",
            "Comparison",
            "N",
            "Mean_Difference",
            "T_statistic",
            "P_value_two_tailed",
            "Significant_at_0.05"
        ]

        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()

        for row in output_rows:
            writer.writerow(row)

    print(f"Results saved to: {TTEST_OUTPUT_FILE}")


# Run the program.
def main():
    if not EVAL_FILE.exists():
        print(f"Missing evaluation file: {EVAL_FILE}")
        print("Please run Evaluation.py first.")
        return

    run_t_tests()


if __name__ == "__main__":
    main()
