from pathlib import Path
import re
import math
import csv
import string
from collections import defaultdict, Counter
from nltk.stem import PorterStemmer


# Run Model_C using hybrid feature-weighted BM25 ranking.

# Set the main folder path.
BASE_DIR = Path(__file__).resolve().parent

# Set the topic file path.
TOPICS_FILE = BASE_DIR / "Topics.txt"
if not TOPICS_FILE.exists():
    # Set the topic file path.
    TOPICS_FILE = BASE_DIR / "Topics"

# Set the document collection folder path.
DOC_DIR = BASE_DIR / "Doc_Collection"
# Set the relevance judgement folder path.
JUDGEMENT_DIR = BASE_DIR / "Relevant_Judgements"
# Set the output folder path.
OUTPUT_DIR = BASE_DIR / "ModelOutputs"
# Set the stop-word file path.
STOP_WORD_FILE = BASE_DIR / "common-english-words.txt"

OUTPUT_DIR.mkdir(exist_ok=True)


# Set the BM25 term-frequency saturation parameter.
BM25_K1 = 1.2
# Set the BM25 query-frequency parameter.
BM25_K2 = 500
# Set the BM25 document-length normalisation parameter.
BM25_B = 0.75


# Set how many top documents are used as pseudo-relevant documents.
FW_TOP_POS = 3
# Set how many bottom documents are used as pseudo-non-relevant documents.
FW_BOTTOM_NEG = 20
# Set the feature selection threshold.
FW_Q_THRESHOLD = 0.0
# Set the maximum number of selected feature terms.
MAX_FEATURE_TERMS = 50


# Set how many top documents are used for query expansion.
PRF_TOP_K = 1
# Set how many expansion terms are added to the query.
PRF_EXPANSION_TERMS = 5


# Set the grid search weight interval.
WEIGHT_STEP = 0.1

# List the ranking components used in Model_C.
COMPONENT_NAMES = ["title", "desc", "narr", "feature_weighted", "prf"]

# Set the reciprocal rank fusion constant.
RRF_K = 60

# List the score fusion methods tested by grid search.
FUSION_METHODS = ["linear", "rrf"]


# Create the Porter stemmer.
stemmer = PorterStemmer()

# Define extra stop words for the Reuters collection.
EXTRA_STOP_WORDS = {
    "reuter", "reuters", "mln", "dlrs", "pct", "quot", "amp", "lt", "gt"
}

# Define fallback English stop words.
DEFAULT_STOP_WORDS = {
    "the", "a", "an", "and", "or", "but", "if", "while", "with", "without",
    "of", "to", "in", "on", "for", "from", "by", "as", "at", "is", "are",
    "was", "were", "be", "been", "being", "this", "that", "these", "those",
    "it", "its", "they", "them", "their", "he", "she", "his", "her",
    "we", "our", "you", "your", "i", "me", "my", "will", "would", "can",
    "could", "should", "may", "might", "about", "into", "over", "after",
    "before", "than", "then", "there", "here", "which", "who", "what",
    "when", "where", "why", "how", "not", "no", "yes", "also", "said",
    "says", "say"
}


# Load the stop-word list used in preprocessing.
def load_stop_words(stop_word_file):
    stop_words = set(DEFAULT_STOP_WORDS)

    if stop_word_file.exists():
        with open(stop_word_file, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read().lower()
            words = re.split(r"[,\s]+", content)
            for word in words:
                word = word.strip()
                if word:
                    stop_words.add(word)

    stop_words.update(EXTRA_STOP_WORDS)
    stop_words.update({stemmer.stem(word) for word in stop_words})

    return stop_words


STOP_WORDS = load_stop_words(STOP_WORD_FILE)


# Store one document as an ID, document length and term-frequency dictionary.
class Doc:
    def __init__(self, docID):
        self.docID = docID
        self.terms = {}
        self.doc_size = 0

    def get_docID(self):
        return self.docID

    def get_doc_size(self):
        return self.doc_size

    def set_doc_size(self, size):
        self.doc_size = size

    def add_term(self, term, stop_wordList):
        if term in stop_wordList:
            return

        if term in self.terms:
            self.terms[term] += 1
        else:
            self.terms[term] = 1


# Extract the document ID from a newsitem line.
def extract_doc_id(line):
    pos = line.find("itemid=")
    if pos == -1:
        return None

    start = pos + len("itemid=")
    if start >= len(line):
        return None

    quote = line[start]
    if quote not in ['"', "'"]:
        return None

    end = line.find(quote, start + 1)
    if end == -1:
        return None

    return line[start + 1:end]


# Remove XML-style tags from one text line.
def remove_inline_tags(text_line):
    result = []
    inside_tag = False

    for ch in text_line:
        if ch == "<":
            inside_tag = True
        elif ch == ">":
            inside_tag = False
        elif not inside_tag:
            result.append(ch)

    return "".join(result)


# Replace common markup entities with spaces.
def replace_markup_entities(line):
    line = line.replace("&quot;", " ")
    line = line.replace("&amp;", " ")
    line = line.replace("&lt;", " ")
    line = line.replace("&gt;", " ")
    line = line.replace("&apos;", " ")
    line = line.replace("&#3;", " ")
    return line


# Convert one raw text line into candidate tokens.
def normalise_line_to_tokens(line):
    line = replace_markup_entities(line)
    line = remove_inline_tags(line)
    line = line.translate(str.maketrans("", "", string.digits))
    line = line.translate(str.maketrans(string.punctuation, " " * len(string.punctuation)))
    return line.split()


# Apply lowercase conversion, stop-word removal and stemming to one token.
def preprocess_token(token, stop_wordList):
    token = token.lower()

    if len(token) <= 2:
        return None

    if token in stop_wordList:
        return None

    token = stemmer.stem(token)

    if len(token) <= 2:
        return None

    if token in stop_wordList:
        return None

    return token


# Add one processed term into a term-frequency dictionary.
def add_term_to_tf_dict(tf_dict, term):
    if term in tf_dict:
        tf_dict[term] += 1
    else:
        tf_dict[term] = 1


# Parse one dataset folder and return document objects indexed by document ID.
def docParser(stop_words, folder):
    coll = {}

    for file_path in sorted(Path(folder).glob("*.xml")):
        doc = None
        inside_text = False
        raw_word_count = 0

        with open(file_path, "r", encoding="iso-8859-1", errors="ignore") as f:
            for raw_line in f:
                line = raw_line.strip()

                if doc is None and "<newsitem" in line and "itemid=" in line:
                    docID = extract_doc_id(line)
                    if docID is not None:
                        doc = Doc(docID)

                if not inside_text:
                    if "<text>" in line:
                        inside_text = True
                        line = line.split("<text>", 1)[1]
                    else:
                        continue

                reached_text_end = False
                if "</text>" in line:
                    line = line.split("</text>", 1)[0]
                    reached_text_end = True

                raw_tokens = normalise_line_to_tokens(line)
                raw_word_count += len(raw_tokens)

                for token in raw_tokens:
                    term = preprocess_token(token, stop_words)
                    if term is not None and doc is not None:
                        doc.add_term(term, stop_words)

                if reached_text_end:
                    break

        if doc is not None:
            doc.set_doc_size(raw_word_count)
            coll[doc.get_docID()] = doc

    return coll


# Parse a query using the same preprocessing steps as the documents.
def queryParser(query, stop_words):
    query_tf = {}
    raw_tokens = normalise_line_to_tokens(query)

    for token in raw_tokens:
        term = preprocess_token(token, stop_words)
        if term is not None:
            add_term_to_tf_dict(query_tf, term)

    return query_tf


# Clean a topic field before query parsing.
def clean_topic_field(text):
    text = re.sub(r"<[^>]+>", " ", text)
    text = text.replace("Description:", " ")
    text = text.replace("Narrative:", " ")
    text = text.replace("description:", " ")
    text = text.replace("narrative:", " ")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


# Remove negative narrative text that may add noise.
def clean_narrative_text(text):
    lower_text = text.lower()

    cut_phrases = [
        "not relevant",
        "irrelevant",
        "are not relevant",
        "is not relevant",
        "will not be relevant",
        "should not be considered",
        "not be considered relevant"
    ]

    cut_positions = []

    for phrase in cut_phrases:
        pos = lower_text.find(phrase)
        if pos != -1:
            cut_positions.append(pos)

    if cut_positions:
        text = text[:min(cut_positions)]

    return text.strip()


# Read topic information from the topic file.
def read_topics(topic_file):
    with open(topic_file, "r", encoding="utf-8", errors="ignore") as f:
        content = f.read()

    topic_blocks = re.findall(r"<Topic>(.*?)</Topic>", content, re.DOTALL | re.IGNORECASE)
    topics = {}

    for block in topic_blocks:
        num_match = re.search(r"<num>\s*Number:\s*(R\d+)", block, re.IGNORECASE)
        title_match = re.search(r"<title>\s*(.*?)(?=<desc>|<narr>|$)", block, re.DOTALL | re.IGNORECASE)
        desc_match = re.search(r"<desc>\s*(.*?)(?=<narr>|$)", block, re.DOTALL | re.IGNORECASE)
        narr_match = re.search(r"<narr>\s*(.*)$", block, re.DOTALL | re.IGNORECASE)

        if num_match:
            topic_id = num_match.group(1).strip()
            title = clean_topic_field(title_match.group(1)) if title_match else ""
            desc = clean_topic_field(desc_match.group(1)) if desc_match else ""
            narr = clean_topic_field(narr_match.group(1)) if narr_match else ""
            narr = clean_narrative_text(narr)

            topics[topic_id] = {
                "title": title,
                "desc": desc,
                "narr": narr
            }

    return topics


# Read relevant document IDs from one judgement file.
def read_relevance_judgements(judgement_file):
    relevant_docs = set()

    if not judgement_file.exists():
        return relevant_docs

    with open(judgement_file, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            parts = line.strip().split()

            if len(parts) < 3:
                continue

            doc_id = parts[1]
            relevance = parts[2]

            if relevance == "1":
                relevant_docs.add(doc_id)

    return relevant_docs


# Count how many documents contain each term.
def document_frequency(coll):
    df_dict = defaultdict(int)

    for doc in coll.values():
        for term in doc.terms.keys():
            df_dict[term] += 1

    return dict(df_dict)


# Calculate the average document length in a collection.
def average_doc_length(coll):
    if len(coll) == 0:
        return 0.0

    return sum(doc.get_doc_size() for doc in coll.values()) / len(coll)


# Count total term frequencies across the whole collection.
def collection_term_frequency(coll):
    ctf = Counter()

    for doc in coll.values():
        ctf.update(doc.terms)

    return ctf


# Calculate JM scores from a parsed query dictionary.
def jm_scores_from_query_tf(coll, query_tf, lambda_value=0.3):
    ctf = collection_term_frequency(coll)
    collection_length = sum(doc.get_doc_size() for doc in coll.values())

    scores = {}

    if collection_length == 0:
        return {docID: 0.0 for docID in coll.keys()}

    for docID, doc in coll.items():
        doc_length = doc.get_doc_size()

        if doc_length == 0:
            scores[docID] = 0.0
            continue

        score = 0.0

        for term, qf in query_tf.items():
            fqj_d = doc.terms.get(term, 0)
            cqj = ctf.get(term, 0)

            if cqj == 0:
                continue

            document_probability = fqj_d / doc_length
            collection_probability = cqj / collection_length

            smoothed_probability = (
                (1 - lambda_value) * document_probability
                + lambda_value * collection_probability
            )

            if smoothed_probability > 0:
                score += qf * math.log10(smoothed_probability)

        scores[docID] = score

    return scores


# Sort document scores from highest to lowest.
def sort_scores(score_dict):
    return sorted(score_dict.items(), key=lambda item: (-item[1], item[0]))


# Calculate BM25 scores from a parsed query dictionary.
def bm25_scores_from_query_tf(coll, query_tf):
    df_dict = document_frequency(coll)
    N = len(coll)
    avdl = average_doc_length(coll)

    scores = {}

    if N == 0 or avdl == 0:
        return {docID: 0.0 for docID in coll.keys()}

    for docID, doc in coll.items():
        score = 0.0
        dl = doc.get_doc_size()

        for term, qf_t in query_tf.items():
            if term not in df_dict:
                continue

            n_t = df_dict[term]
            f_t = doc.terms.get(term, 0)

            if f_t == 0:
                continue

            K = BM25_K1 * ((1 - BM25_B) + BM25_B * dl / avdl)

            idf = math.log10(1 + (N - n_t + 0.5) / (n_t + 0.5))
            tf_component = ((BM25_K1 + 1) * f_t) / (K + f_t)
            qf_component = ((BM25_K2 + 1) * qf_t) / (BM25_K2 + qf_t)

            score += idf * tf_component * qf_component

        scores[docID] = score

    return scores


# Normalise score values into the range from 0 to 1.
def min_max_normalise(score_dict):
    if not score_dict:
        return {}

    values = list(score_dict.values())
    min_value = min(values)
    max_value = max(values)

    if max_value == min_value:
        return {key: 0.0 for key in score_dict.keys()}

    return {
        key: (value - min_value) / (max_value - min_value)
        for key, value in score_dict.items()
    }


# Convert document scores into document ranks.
def rank_dict_from_scores(score_dict):
    ranked = sort_scores(score_dict)
    return {docID: rank for rank, (docID, _) in enumerate(ranked, start=1)}


# Build an expanded query from pseudo-relevant documents.
def prf_expanded_query_tf(coll, original_query_tf, initial_rankings, top_k, expansion_terms):
    df_dict = document_frequency(coll)
    N = len(coll)

    term_counter = Counter()

    for docID, _ in initial_rankings[:top_k]:
        doc = coll.get(docID)
        if doc is not None:
            term_counter.update(doc.terms)

    candidates = []

    for term, freq in term_counter.items():
        if term in original_query_tf:
            continue

        n_t = df_dict.get(term, 0)
        if n_t == 0:
            continue

        idf = math.log10(1 + (N - n_t + 0.5) / (n_t + 0.5))
        score = freq * idf
        candidates.append((term, score))

    candidates.sort(key=lambda item: (-item[1], item[0]))

    expanded_query_tf = dict(original_query_tf)

    for term, _ in candidates[:expansion_terms]:
        expanded_query_tf[term] = expanded_query_tf.get(term, 0) + 1

    return expanded_query_tf


# Calculate w5 feature weights from pseudo-relevant and pseudo-non-relevant documents.
def compute_w5_from_pseudo_training(coll, initial_rankings, top_pos, bottom_neg, q_threshold):
    if len(initial_rankings) == 0:
        return {}, {}

    pseudo_pos_ids = [docID for docID, _ in initial_rankings[:top_pos]]
    pseudo_neg_ids = [docID for docID, _ in initial_rankings[-bottom_neg:]]

    pseudo_pos_set = set(pseudo_pos_ids)
    pseudo_neg_ids = [docID for docID in pseudo_neg_ids if docID not in pseudo_pos_set]

    pseudo_doc_ids = pseudo_pos_ids + pseudo_neg_ids

    N = len(pseudo_doc_ids)
    R = len(pseudo_pos_ids)

    if N == 0 or R == 0:
        return {}, {}

    n_count = defaultdict(int)
    r_count = defaultdict(int)
    positive_terms = set()

    for docID in pseudo_doc_ids:
        doc = coll.get(docID)
        if doc is None:
            continue

        term_set = set(doc.terms.keys())

        for term in term_set:
            n_count[term] += 1

        if docID in pseudo_pos_set:
            positive_terms.update(term_set)
            for term in term_set:
                r_count[term] += 1

    all_w5 = {}

    for term in sorted(positive_terms):
        n_t = n_count.get(term, 0)
        r_t = r_count.get(term, 0)

        positive_odds = (r_t + 0.5) / (R - r_t + 0.5)

        negative_denominator = (N - n_t) - (R - r_t) + 0.5
        if negative_denominator <= 0:
            negative_denominator = 0.5

        negative_odds = (n_t - r_t + 0.5) / negative_denominator

        if negative_odds <= 0:
            continue

        all_w5[term] = positive_odds / negative_odds

    if not all_w5:
        return {}, {}

    mean_w5 = sum(all_w5.values()) / len(all_w5)
    threshold = mean_w5 + q_threshold

    selected_items = [
        (term, weight)
        for term, weight in all_w5.items()
        if weight > threshold
    ]

    selected_items.sort(key=lambda item: (-item[1], item[0]))
    selected_items = selected_items[:MAX_FEATURE_TERMS]

    return dict(selected_items), all_w5


# Calculate Feature-Weighted BM25 scores using selected terms.
def feature_weighted_scores(coll, selected_w5):
    df_dict = document_frequency(coll)
    N = len(coll)
    avdl = average_doc_length(coll)

    scores = {}

    if N == 0 or avdl == 0 or not selected_w5:
        return {docID: 0.0 for docID in coll.keys()}

    for docID, doc in coll.items():
        score = 0.0
        dl = doc.get_doc_size()

        for term, w5_value in selected_w5.items():
            f_t = doc.terms.get(term, 0)

            if f_t == 0:
                continue

            n_t = df_dict.get(term, 0)
            if n_t == 0:
                continue

            K = BM25_K1 * ((1 - BM25_B) + BM25_B * dl / avdl)
            idf = math.log10(1 + (N - n_t + 0.5) / (n_t + 0.5))
            tf_component = ((BM25_K1 + 1) * f_t) / (K + f_t)
            w5_component = math.log1p(w5_value)

            score += w5_component * idf * tf_component

        scores[docID] = score

    return scores


# Build all ranking component scores for one topic.
def build_components_for_topic(coll, topic_fields):
    title_tf = queryParser(topic_fields["title"], STOP_WORDS)
    desc_tf = queryParser(topic_fields["desc"], STOP_WORDS)
    narr_tf = queryParser(topic_fields["narr"], STOP_WORDS)

    title_scores = bm25_scores_from_query_tf(coll, title_tf)
    desc_scores = bm25_scores_from_query_tf(coll, desc_tf)
    narr_scores = bm25_scores_from_query_tf(coll, narr_tf)

    title_rankings = sort_scores(title_scores)

    selected_w5, all_w5 = compute_w5_from_pseudo_training(
        coll=coll,
        initial_rankings=title_rankings,
        top_pos=FW_TOP_POS,
        bottom_neg=FW_BOTTOM_NEG,
        q_threshold=FW_Q_THRESHOLD
    )

    feature_scores = feature_weighted_scores(coll, selected_w5)

    expanded_tf = prf_expanded_query_tf(
        coll=coll,
        original_query_tf=title_tf,
        initial_rankings=title_rankings,
        top_k=PRF_TOP_K,
        expansion_terms=PRF_EXPANSION_TERMS
    )

    prf_scores = bm25_scores_from_query_tf(coll, expanded_tf)

    baseline2_jm_scores = jm_scores_from_query_tf(coll, title_tf)

    return {
        "title": title_scores,
        "desc": desc_scores,
        "narr": narr_scores,
        "feature_weighted": feature_scores,
        "prf": prf_scores
    }, selected_w5, baseline2_jm_scores


# Generate score-fusion weight combinations for grid search.
def generate_weight_combinations(step=0.1):
    units = int(round(1.0 / step))
    combinations = []

    for a in range(units + 1):
        for b in range(units + 1 - a):
            for c in range(units + 1 - a - b):
                for d in range(units + 1 - a - b - c):
                    e = units - a - b - c - d

                    weights = {
                        "title": a * step,
                        "desc": b * step,
                        "narr": c * step,
                        "feature_weighted": d * step,
                        "prf": e * step
                    }

                    if weights["title"] < 0.1:
                        continue

                    combinations.append(weights)

    return combinations


# Combine component scores using weighted linear fusion.
def fuse_scores_linear(components, weights):
    norm_components = {
        name: min_max_normalise(scores)
        for name, scores in components.items()
    }

    doc_ids = set()
    for scores in components.values():
        doc_ids.update(scores.keys())

    final_scores = {}

    for docID in doc_ids:
        score = 0.0
        for name in COMPONENT_NAMES:
            score += weights[name] * norm_components[name].get(docID, 0.0)
        final_scores[docID] = score

    return final_scores


# Combine component rankings using reciprocal rank fusion.
def fuse_scores_rrf(components, weights):
    ranks = {
        name: rank_dict_from_scores(scores)
        for name, scores in components.items()
    }

    doc_ids = set()
    for scores in components.values():
        doc_ids.update(scores.keys())

    final_scores = {}

    for docID in doc_ids:
        score = 0.0
        for name in COMPONENT_NAMES:
            rank = ranks[name].get(docID)
            if rank is not None:
                score += weights[name] / (RRF_K + rank)
        final_scores[docID] = score

    return final_scores


# Apply the selected score fusion method.
def fuse_scores(components, weights, method):
    if method == "linear":
        return fuse_scores_linear(components, weights)

    if method == "rrf":
        return fuse_scores_rrf(components, weights)

    raise ValueError(f"Unknown fusion method: {method}")


# Calculate Average Precision for one ranked list.
def average_precision(ranked_doc_ids, relevant_docs):
    if len(relevant_docs) == 0:
        return 0.0

    relevant_retrieved = 0
    precision_sum = 0.0

    for rank, doc_id in enumerate(ranked_doc_ids, start=1):
        if doc_id in relevant_docs:
            relevant_retrieved += 1
            precision_sum += relevant_retrieved / rank

    return precision_sum / len(relevant_docs)


# Calculate Precision at rank 10.
def precision_at_10(ranked_doc_ids, relevant_docs):
    top_10 = ranked_doc_ids[:10]
    return sum(1 for doc_id in top_10 if doc_id in relevant_docs) / 10


# Calculate DCG at rank 10.
def dcg_at_10(ranked_doc_ids, relevant_docs):
    top_10 = ranked_doc_ids[:10]
    dcg = 0.0

    for i, doc_id in enumerate(top_10, start=1):
        rel_i = 1 if doc_id in relevant_docs else 0
        if i == 1:
            dcg += rel_i
        else:
            dcg += rel_i / math.log2(i)

    return dcg


# Calculate average evaluation metrics for ranking results.
def evaluate_rankings(final_scores_by_topic, cached_data):
    ap_scores = []
    p10_scores = []
    dcg_scores = []

    for topic_id in sorted(final_scores_by_topic.keys()):
        rankings = sort_scores(final_scores_by_topic[topic_id])
        ranked_doc_ids = [docID for docID, _ in rankings]
        relevant_docs = cached_data[topic_id]["relevant_docs"]

        ap_scores.append(average_precision(ranked_doc_ids, relevant_docs))
        p10_scores.append(precision_at_10(ranked_doc_ids, relevant_docs))
        dcg_scores.append(dcg_at_10(ranked_doc_ids, relevant_docs))

    return {
        "MAP": sum(ap_scores) / len(ap_scores),
        "Average_P@10": sum(p10_scores) / len(p10_scores),
        "Average_DCG@10": sum(dcg_scores) / len(dcg_scores)
    }


# Calculate evaluation metrics for each topic.
def evaluate_rankings_by_topic(final_scores_by_topic, cached_data):
    topic_metrics = {}

    for topic_id in sorted(final_scores_by_topic.keys()):
        rankings = sort_scores(final_scores_by_topic[topic_id])
        ranked_doc_ids = [docID for docID, _ in rankings]
        relevant_docs = cached_data[topic_id]["relevant_docs"]

        topic_metrics[topic_id] = {
            "AveragePrecision": average_precision(ranked_doc_ids, relevant_docs),
            "Precision@10": precision_at_10(ranked_doc_ids, relevant_docs),
            "DCG@10": dcg_at_10(ranked_doc_ids, relevant_docs)
        }

    return topic_metrics


# Calculate per-topic metrics for a baseline model.
def baseline_metrics_by_topic(cached_data, baseline_key):
    scores_by_topic = {
        topic_id: data[baseline_key]
        for topic_id, data in cached_data.items()
    }

    return evaluate_rankings_by_topic(scores_by_topic, cached_data)


# Calculate the paired t-statistic for validation.
def paired_t_stat(model_values, baseline_values):
    diffs = [m - b for m, b in zip(model_values, baseline_values)]
    n = len(diffs)

    if n <= 1:
        return 0.0, 0.0

    mean_diff = sum(diffs) / n

    variance = sum((d - mean_diff) ** 2 for d in diffs) / (n - 1)

    if variance <= 0:
        return 0.0, mean_diff

    std_diff = math.sqrt(variance)
    t_stat = mean_diff / (std_diff / math.sqrt(n))

    return t_stat, mean_diff


# Summarise paired t-statistics for all metrics.
def significance_summary(model_topic_metrics, baseline1_topic_metrics, baseline2_topic_metrics):
    topic_ids = sorted(model_topic_metrics.keys())

    summary = {}

    for metric in ["AveragePrecision", "Precision@10", "DCG@10"]:
        model_values = [model_topic_metrics[t][metric] for t in topic_ids]
        b1_values = [baseline1_topic_metrics[t][metric] for t in topic_ids]
        b2_values = [baseline2_topic_metrics[t][metric] for t in topic_ids]

        t_b1, diff_b1 = paired_t_stat(model_values, b1_values)
        t_b2, diff_b2 = paired_t_stat(model_values, b2_values)

        summary[f"{metric}_t_vs_Baseline1"] = t_b1
        summary[f"{metric}_diff_vs_Baseline1"] = diff_b1
        summary[f"{metric}_t_vs_Baseline2"] = t_b2
        summary[f"{metric}_diff_vs_Baseline2"] = diff_b2

    return summary


# Load all datasets and build the data needed by Model_C.
def load_all_data(topics):
    cached_data = {}

    for topic_num in range(101, 151):
        topic_id = f"R{topic_num}"
        dataset_path = DOC_DIR / f"Dataset{topic_num}"
        judgement_file = JUDGEMENT_DIR / f"Dataset{topic_num}.txt"

        if topic_id not in topics:
            print(f"Warning: {topic_id} not found in Topics file.")
            continue

        if not dataset_path.exists():
            print(f"Warning: missing dataset folder: {dataset_path}")
            continue

        coll = docParser(STOP_WORDS, dataset_path)
        relevant_docs = read_relevance_judgements(judgement_file)

        components, selected_w5, baseline2_jm_scores = build_components_for_topic(coll, topics[topic_id])

        cached_data[topic_id] = {
            "topic_fields": topics[topic_id],
            "coll": coll,
            "relevant_docs": relevant_docs,
            "components": components,
            "selected_w5": selected_w5,
            "baseline1_scores": components["title"],
            "baseline2_scores": baseline2_jm_scores
        }

    return cached_data


# Search for the best fusion method and component weights.
def grid_search_hybrid(cached_data):
    weight_combinations = generate_weight_combinations(WEIGHT_STEP)
    grid_rows = []

    baseline1_topic_metrics = baseline_metrics_by_topic(cached_data, "baseline1_scores")
    baseline2_topic_metrics = baseline_metrics_by_topic(cached_data, "baseline2_scores")

    print("Running Model_C grid search...")

    checked = 0

    for method in FUSION_METHODS:
        for weights in weight_combinations:
            final_scores_by_topic = {}

            for topic_id, data in cached_data.items():
                final_scores_by_topic[topic_id] = fuse_scores(
                    components=data["components"],
                    weights=weights,
                    method=method
                )

            metrics = evaluate_rankings(final_scores_by_topic, cached_data)
            model_topic_metrics = evaluate_rankings_by_topic(final_scores_by_topic, cached_data)
            sig = significance_summary(model_topic_metrics, baseline1_topic_metrics, baseline2_topic_metrics)

            min_ap_t = min(
                sig["AveragePrecision_t_vs_Baseline1"],
                sig["AveragePrecision_t_vs_Baseline2"]
            )

            min_dcg_t = min(
                sig["DCG@10_t_vs_Baseline1"],
                sig["DCG@10_t_vs_Baseline2"]
            )

            min_p10_t = min(
                sig["Precision@10_t_vs_Baseline1"],
                sig["Precision@10_t_vs_Baseline2"]
            )

            significance_objective = (
                1.00 * min_ap_t
                + 0.35 * min_dcg_t
                + 0.20 * min_p10_t
                + 2.00 * metrics["MAP"]
            )

            row = {
                "method": method,
                "w_title": weights["title"],
                "w_desc": weights["desc"],
                "w_narr": weights["narr"],
                "w_feature_weighted": weights["feature_weighted"],
                "w_prf": weights["prf"],
                "MAP": metrics["MAP"],
                "Average_P@10": metrics["Average_P@10"],
                "Average_DCG@10": metrics["Average_DCG@10"],
                "AP_t_vs_Baseline1": sig["AveragePrecision_t_vs_Baseline1"],
                "AP_t_vs_Baseline2": sig["AveragePrecision_t_vs_Baseline2"],
                "P10_t_vs_Baseline1": sig["Precision@10_t_vs_Baseline1"],
                "P10_t_vs_Baseline2": sig["Precision@10_t_vs_Baseline2"],
                "DCG_t_vs_Baseline1": sig["DCG@10_t_vs_Baseline1"],
                "DCG_t_vs_Baseline2": sig["DCG@10_t_vs_Baseline2"],
                "Significance_Objective": significance_objective
            }

            grid_rows.append(row)
            checked += 1

    grid_rows.sort(
        key=lambda row: (
            row["Significance_Objective"],
            row["MAP"],
            row["Average_DCG@10"],
            row["Average_P@10"]
        ),
        reverse=True
    )

    return grid_rows

# Save grid search results to a CSV file.
def save_grid_search_results(grid_rows):
    output_file = OUTPUT_DIR / "ModelC_Hybrid_GridSearch_Results.csv"

    with open(output_file, "w", newline="", encoding="utf-8") as f:
        fieldnames = [
            "method",
            "w_title",
            "w_desc",
            "w_narr",
            "w_feature_weighted",
            "w_prf",
            "MAP",
            "Average_P@10",
            "Average_DCG@10",
            "AP_t_vs_Baseline1",
            "AP_t_vs_Baseline2",
            "P10_t_vs_Baseline1",
            "P10_t_vs_Baseline2",
            "DCG_t_vs_Baseline1",
            "DCG_t_vs_Baseline2",
            "Significance_Objective"
        ]

        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()

        for row in grid_rows:
            writer.writerow(row)

    print(f"\nGrid search results saved to: {output_file}")


# Generate final Model_C ranking files using the best setting.
def generate_final_outputs(best_params, cached_data):
    method = best_params["method"]
    weights = {
        "title": float(best_params["w_title"]),
        "desc": float(best_params["w_desc"]),
        "narr": float(best_params["w_narr"]),
        "feature_weighted": float(best_params["w_feature_weighted"]),
        "prf": float(best_params["w_prf"])
    }

    summary_file = OUTPUT_DIR / "ModelC_Top10_Summary.txt"
    param_file = OUTPUT_DIR / "ModelC_Hybrid_Parameters.txt"

    with open(summary_file, "w", encoding="utf-8") as summary, \
         open(param_file, "w", encoding="utf-8") as param_log:

        param_log.write("Model_C: Optimised Hybrid Feature-Weighted BM25\n")
        param_log.write(f"Fusion method: {method}\n")
        param_log.write(f"Weights: {weights}\n")
        param_log.write(f"FW_TOP_POS = {FW_TOP_POS}\n")
        param_log.write(f"FW_BOTTOM_NEG = {FW_BOTTOM_NEG}\n")
        param_log.write(f"FW_Q_THRESHOLD = {FW_Q_THRESHOLD}\n")
        param_log.write(f"PRF_TOP_K = {PRF_TOP_K}\n")
        param_log.write(f"PRF_EXPANSION_TERMS = {PRF_EXPANSION_TERMS}\n")
        param_log.write(f"RRF_K = {RRF_K}\n")

        for topic_id in sorted(cached_data.keys()):
            data = cached_data[topic_id]

            final_scores = fuse_scores(
                components=data["components"],
                weights=weights,
                method=method
            )

            rankings = sort_scores(final_scores)

            output_file = OUTPUT_DIR / f"ModelC_{topic_id}_Ranking.dat"

            with open(output_file, "w", encoding="utf-8") as f:
                f.write("Doc_ID HybridFeatureWeightedBM25_Score\n")
                for docID, score in rankings:
                    f.write(f"{docID} {score}\n")

            summary.write(f"{topic_id}\n")
            summary.write(f"Title: {data['topic_fields']['title']}\n")
            summary.write("Doc_ID HybridFeatureWeightedBM25_Score\n")
            for docID, score in rankings[:10]:
                summary.write(f"{docID} {score}\n")
            summary.write("\n")

    print("Model_C completed.")
    print(f"Output folder: {OUTPUT_DIR}")
    print(f"Top-10 summary: {summary_file}")
    print(f"Parameter log: {param_file}")


# Run the program.
def main():
    topics = read_topics(TOPICS_FILE)

    cached_data = load_all_data(topics)

    if len(cached_data) == 0:
        print("No data loaded. Please check Doc_Collection, Relevant_Judgements and Topics.txt.")
        return

    grid_rows = grid_search_hybrid(cached_data)
    save_grid_search_results(grid_rows)

    best_params = grid_rows[0]

    print("Best Model_C setting:")
    print(best_params)

    generate_final_outputs(best_params, cached_data)

    print("Next: run Evaluation.py and TTest_A2.py")


if __name__ == "__main__":
    main()
