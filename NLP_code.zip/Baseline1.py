from pathlib import Path
import re
import math
import string
from collections import Counter, defaultdict
from nltk.stem import PorterStemmer


# Run Baseline1 using BM25 ranking.

# Set the main folder path.
BASE_DIR = Path(__file__).resolve().parent

# Set the topic file path.
TOPICS_FILE = BASE_DIR / "Topics.txt"
if not TOPICS_FILE.exists():
    # Set the topic file path.
    TOPICS_FILE = BASE_DIR / "Topics"

# Set the document collection folder path.
DOC_DIR = BASE_DIR / "Doc_Collection"
# Set the output folder path.
OUTPUT_DIR = BASE_DIR / "ModelOutputs"
# Set the stop-word file path.
STOP_WORD_FILE = BASE_DIR / "common-english-words.txt"

OUTPUT_DIR.mkdir(exist_ok=True)


# Create the Porter stemmer.
stemmer = PorterStemmer()

# Define extra stop words for the Reuters collection.
EXTRA_STOP_WORDS = {
    "reuter", "reuters", "mln", "dlrs", "pct", "quot", "amp", "lt", "gt"
}

# Define fallback English stop words.
DEFAULT_STOP_WORDS = {
    "the", "a", "an", "and", "or", "but", "if", "while", "with", "without",
    "of", "to", "in", "on", "for", "from", "by", "as", "at", "is", "are",
    "was", "were", "be", "been", "being", "this", "that", "these", "those",
    "it", "its", "they", "them", "their", "he", "she", "his", "her",
    "we", "our", "you", "your", "i", "me", "my", "will", "would", "can",
    "could", "should", "may", "might", "about", "into", "over", "after",
    "before", "than", "then", "there", "here", "which", "who", "what",
    "when", "where", "why", "how", "not", "no", "yes", "also", "said",
    "says", "say"
}


# Load the stop-word list used in preprocessing.
def load_stop_words(stop_word_file):
    stop_words = set(DEFAULT_STOP_WORDS)

    if stop_word_file.exists():
        with open(stop_word_file, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read().lower()
            words = re.split(r"[,\s]+", content)
            for word in words:
                word = word.strip()
                if word:
                    stop_words.add(word)

    stop_words.update(EXTRA_STOP_WORDS)

    stemmed_stop_words = {stemmer.stem(word) for word in stop_words}
    stop_words.update(stemmed_stop_words)

    return stop_words


STOP_WORDS = load_stop_words(STOP_WORD_FILE)


# Store one document as an ID, document length and term-frequency dictionary.
class Doc:

    def __init__(self, docID):
        self.docID = docID
        self.terms = {}
        self.doc_size = 0

    def get_docID(self):
        return self.docID

    def get_doc_size(self):
        return self.doc_size

    def set_doc_size(self, size):
        self.doc_size = size

    def get_termList(self):
        return sorted(self.terms.keys())

    def add_term(self, term, stop_wordList):
        if term in stop_wordList:
            return

        if term in self.terms:
            self.terms[term] += 1
        else:
            self.terms[term] = 1


# Extract the document ID from a newsitem line.
def extract_doc_id(line):
    pos = line.find("itemid=")
    if pos == -1:
        return None

    start = pos + len("itemid=")
    if start >= len(line):
        return None

    quote = line[start]
    if quote not in ['"', "'"]:
        return None

    end = line.find(quote, start + 1)
    if end == -1:
        return None

    return line[start + 1:end]


# Remove XML-style tags from one text line.
def remove_inline_tags(text_line):
    result = []
    inside_tag = False

    for ch in text_line:
        if ch == "<":
            inside_tag = True
        elif ch == ">":
            inside_tag = False
        elif not inside_tag:
            result.append(ch)

    return "".join(result)


# Replace common markup entities with spaces.
def replace_markup_entities(line):
    line = line.replace("&quot;", " ")
    line = line.replace("&amp;", " ")
    line = line.replace("&lt;", " ")
    line = line.replace("&gt;", " ")
    line = line.replace("&apos;", " ")
    line = line.replace("&#3;", " ")
    return line


# Convert one raw text line into candidate tokens.
def normalise_line_to_tokens(line):
    line = replace_markup_entities(line)
    line = remove_inline_tags(line)

    line = line.translate(str.maketrans("", "", string.digits))
    line = line.translate(str.maketrans(string.punctuation, " " * len(string.punctuation)))

    return line.split()


# Apply lowercase conversion, stop-word removal and stemming to one token.
def preprocess_token(token, stop_wordList):
    token = token.lower()

    if len(token) <= 2:
        return None

    if token in stop_wordList:
        return None

    token = stemmer.stem(token)

    if len(token) <= 2:
        return None

    if token in stop_wordList:
        return None

    return token


# Add one processed term into a term-frequency dictionary.
def add_term_to_tf_dict(tf_dict, term):
    if term in tf_dict:
        tf_dict[term] += 1
    else:
        tf_dict[term] = 1


# Parse one dataset folder and return document objects indexed by document ID.
def docParser(stop_words, folder):
    coll = {}

    for file_path in sorted(Path(folder).glob("*.xml")):
        doc = None
        inside_text = False
        raw_word_count = 0

        with open(file_path, "r", encoding="iso-8859-1", errors="ignore") as f:
            for raw_line in f:
                line = raw_line.strip()

                if doc is None and "<newsitem" in line and "itemid=" in line:
                    docID = extract_doc_id(line)
                    if docID is not None:
                        doc = Doc(docID)

                if not inside_text:
                    if "<text>" in line:
                        inside_text = True
                        line = line.split("<text>", 1)[1]
                    else:
                        continue

                reached_text_end = False
                if "</text>" in line:
                    line = line.split("</text>", 1)[0]
                    reached_text_end = True

                raw_tokens = normalise_line_to_tokens(line)
                raw_word_count += len(raw_tokens)

                for token in raw_tokens:
                    term = preprocess_token(token, stop_words)
                    if term is not None and doc is not None:
                        doc.add_term(term, stop_words)

                if reached_text_end:
                    break

        if doc is not None:
            doc.set_doc_size(raw_word_count)
            coll[doc.get_docID()] = doc

    return coll


# Parse a query using the same preprocessing steps as the documents.
def queryParser(query, stop_words):
    query_tf = {}
    raw_tokens = normalise_line_to_tokens(query)

    for token in raw_tokens:
        term = preprocess_token(token, stop_words)
        if term is not None:
            add_term_to_tf_dict(query_tf, term)

    return query_tf


# Read topic information from the topic file.
def read_topics(topic_file):
    with open(topic_file, "r", encoding="utf-8", errors="ignore") as f:
        content = f.read()

    topic_blocks = re.findall(r"<Topic>(.*?)</Topic>", content, re.DOTALL | re.IGNORECASE)
    topics = {}

    for block in topic_blocks:
        num_match = re.search(r"<num>\s*Number:\s*(R\d+)", block, re.IGNORECASE)
        title_match = re.search(r"<title>\s*(.*?)\s*(?:<desc>|$)", block, re.DOTALL | re.IGNORECASE)

        if num_match and title_match:
            topic_id = num_match.group(1).strip()
            title = title_match.group(1).strip()
            topics[topic_id] = title

    return topics


# Count how many documents contain each term.
def document_frequency(coll):
    df_dict = defaultdict(int)

    for doc in coll.values():
        for term in doc.terms.keys():
            df_dict[term] += 1

    return dict(df_dict)


# Calculate the average document length in a collection.
def average_doc_length(coll):
    if len(coll) == 0:
        return 0.0

    return sum(doc.get_doc_size() for doc in coll.values()) / len(coll)


# Count total term frequencies across the whole collection.
def collection_term_frequency(coll):
    ctf = Counter()

    for doc in coll.values():
        ctf.update(doc.terms)

    return ctf


# Sort document scores from highest to lowest.
def sort_scores(score_dict):
    return sorted(score_dict.items(), key=lambda item: (-item[1], item[0]))


# Set the BM25 term-frequency saturation parameter.
BM25_K1 = 1.2
# Set the BM25 query-frequency parameter.
BM25_K2 = 500
# Set the BM25 document-length normalisation parameter.
BM25_B = 0.75


# Calculate BM25 scores for Baseline1.
def baseline1_bm25_scores(coll, query, stop_words):
    query_tf = queryParser(query, stop_words)
    df_dict = document_frequency(coll)

    N = len(coll)
    avdl = average_doc_length(coll)

    scores = {}

    if N == 0 or avdl == 0:
        return {docID: 0.0 for docID in coll.keys()}

    for docID, doc in coll.items():
        score = 0.0
        dl = doc.get_doc_size()

        for term, qf_t in query_tf.items():
            if term not in df_dict:
                continue

            n_t = df_dict[term]
            f_t = doc.terms.get(term, 0)

            if f_t == 0:
                continue

            K = BM25_K1 * ((1 - BM25_B) + BM25_B * dl / avdl)

            idf = math.log10(1 + (N - n_t + 0.5) / (n_t + 0.5))
            tf_component = ((BM25_K1 + 1) * f_t) / (K + f_t)
            qf_component = ((BM25_K2 + 1) * qf_t) / (BM25_K2 + qf_t)

            score += idf * tf_component * qf_component

        scores[docID] = score

    return scores


# Run Baseline1 for all topics and save ranking outputs.
def run_baseline1(topics):
    summary_file = OUTPUT_DIR / "Baseline1_Top10_Summary.txt"

    with open(summary_file, "w", encoding="utf-8") as summary:
        for topic_id in sorted(topics.keys()):
            dataset_number = topic_id.replace("R", "")
            dataset_path = DOC_DIR / f"Dataset{dataset_number}"

            query = topics[topic_id]
            coll = docParser(STOP_WORDS, dataset_path)

            scores = baseline1_bm25_scores(coll, query, STOP_WORDS)
            rankings = sort_scores(scores)

            output_file = OUTPUT_DIR / f"Baseline1_{topic_id}_Ranking.dat"

            with open(output_file, "w", encoding="utf-8") as f:
                f.write("Doc_ID BM25_Score\n")
                for docID, score in rankings:
                    f.write(f"{docID} {score}\n")

            summary.write(f"{topic_id} ({query})\n")
            summary.write("Doc_ID BM25_Score\n")
            for docID, score in rankings[:10]:
                summary.write(f"{docID} {score}\n")
            summary.write("\n")

    print("Baseline1 completed.")
    print(f"Output folder: {OUTPUT_DIR}")


# Run the program.
def main():
    topics = read_topics(TOPICS_FILE)
    run_baseline1(topics)


if __name__ == "__main__":
    main()
