#include "matrixMultiply.h"

// Assuming floatType is std::complex<double> for higher precision
void setZero(int N, floatType* C) {
    memset(C, 0, sizeof(floatType) * N * N);  // Set the matrix C to zero
}

void matrixMultiply(int N, const floatType* A, const floatType* B, floatType* C, int* args, int argCount) {
    const int TILE_WIDTH = 64;  // Adjusted tile size for better performance on large matrices

    // Initialize the result matrix with zeros
    setZero(N, C);

    #pragma omp parallel for schedule(static)
    for (int ii = 0; ii < N; ii += TILE_WIDTH) {
        for (int jj = 0; jj < N; jj += TILE_WIDTH) {
            for (int kk = 0; kk < N; kk += TILE_WIDTH) {
                for (int i = ii; i < std::min(ii + TILE_WIDTH, N); i++) {
                    int iN = i * N;
                    for (int k = kk; k < std::min(kk + TILE_WIDTH, N); k++) {
                        int kN = k * N;
                        double b_real = B[iN + k].real();
                        double b_imag = B[iN + k].imag();

                        int j = jj;
                        for (; j <= jj + TILE_WIDTH - 4 && j <= N - 4; j += 4) {
                            // Precompute indices
                            int kNj0 = kN + j;
                            int kNj1 = kNj0 + 1;
                            int kNj2 = kNj0 + 2;
                            int kNj3 = kNj0 + 3;

                            int iNj0 = iN + j;
                            int iNj1 = iNj0 + 1;
                            int iNj2 = iNj0 + 2;
                            int iNj3 = iNj0 + 3;

                            // Load A elements using _mm256_set_pd
                            __m256d a_real = _mm256_set_pd(
                                A[kNj3].real(),
                                A[kNj2].real(),
                                A[kNj1].real(),
                                A[kNj0].real()
                            );

                            __m256d a_imag = _mm256_set_pd(
                                A[kNj3].imag(),
                                A[kNj2].imag(),
                                A[kNj1].imag(),
                                A[kNj0].imag()
                            );

                            // Load C elements
                            __m256d c_real = _mm256_set_pd(
                                C[iNj3].real(),
                                C[iNj2].real(),
                                C[iNj1].real(),
                                C[iNj0].real()
                            );

                            __m256d c_imag = _mm256_set_pd(
                                C[iNj3].imag(),
                                C[iNj2].imag(),
                                C[iNj1].imag(),
                                C[iNj0].imag()
                            );

                            // Compute real part: c_real += b_real * a_real - b_imag * a_imag
                            __m256d b_real_vec = _mm256_set1_pd(b_real);
                            __m256d b_imag_vec = _mm256_set1_pd(b_imag);

                            __m256d temp1 = _mm256_mul_pd(b_real_vec, a_real);
                            __m256d temp2 = _mm256_mul_pd(b_imag_vec, a_imag);
                            c_real = _mm256_add_pd(c_real, _mm256_sub_pd(temp1, temp2));

                            // Compute imaginary part: c_imag += b_real * a_imag + b_imag * a_real
                            temp1 = _mm256_mul_pd(b_real_vec, a_imag);
                            temp2 = _mm256_mul_pd(b_imag_vec, a_real);
                            c_imag = _mm256_add_pd(c_imag, _mm256_add_pd(temp1, temp2));

                            // Store results back to C
                            alignas(32) double temp_c_real[4];
                            alignas(32) double temp_c_imag[4];
                            _mm256_store_pd(temp_c_real, c_real);
                            _mm256_store_pd(temp_c_imag, c_imag);

                            // Assign results back to C (adjusting for ordering)
                            C[iNj0].real(temp_c_real[0]);
                            C[iNj0].imag(temp_c_imag[0]);
                            C[iNj1].real(temp_c_real[1]);
                            C[iNj1].imag(temp_c_imag[1]);
                            C[iNj2].real(temp_c_real[2]);
                            C[iNj2].imag(temp_c_imag[2]);
                            C[iNj3].real(temp_c_real[3]);
                            C[iNj3].imag(temp_c_imag[3]);
                        }

                        // Handle remaining elements
                        for (; j < std::min(jj + TILE_WIDTH, N); j++) {
                            int kNj = kN + j;
                            int iNj = iN + j;

                            double a_real = A[kNj].real();
                            double a_imag = A[kNj].imag();

                            C[iNj].real(C[iNj].real() + b_real * a_real - b_imag * a_imag);
                            C[iNj].imag(C[iNj].imag() + b_real * a_imag + b_imag * a_real);
                        }
                    }
                }
            }
        }
    }
}
