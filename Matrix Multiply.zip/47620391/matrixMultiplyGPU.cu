#include "matrixMultiplyGPU.cuh"
#define FORTRAN_OFFSET(row, col, ld) ((col) * (ld) + (row))  // Fortran order
const int TILE_WIDTH = 16;

// Device kernel for matrix multiplication using tiled approach
__global__ void matrixMultiplyKernel_GPU(int N, const floatTypeCUDA* A, const floatTypeCUDA* B, floatTypeCUDA* C, int flag0, int flag1, int flag2) {
    int bx = blockIdx.x;
    int by = blockIdx.y;
    int tx = threadIdx.x;
    int ty = threadIdx.y;

    int row = by * TILE_WIDTH + ty;  // Row index of the thread block
    int col = bx * TILE_WIDTH + tx;  // Column index of the thread block

    // Initialize result to 0
    floatTypeCUDA value = make_double2(0.0, 0.0);

    // Use shared memory to store tiles of A and B
    __shared__ floatTypeCUDA A_tile[TILE_WIDTH][TILE_WIDTH];
    __shared__ floatTypeCUDA B_tile[TILE_WIDTH][TILE_WIDTH];

    // Loop over all tiles
    for (int m = 0; m < (N - 1) / TILE_WIDTH + 1; ++m) {
        // Load a tile of matrix A in column-major order
        if (row < N && (m * TILE_WIDTH + tx) < N)
            A_tile[ty][tx] = A[FORTRAN_OFFSET(row, m * TILE_WIDTH + tx, N)];
        else
            A_tile[ty][tx] = make_double2(0.0, 0.0);

        // Load a tile of matrix B in column-major order
        if (col < N && (m * TILE_WIDTH + ty) < N)
            B_tile[ty][tx] = B[FORTRAN_OFFSET(m * TILE_WIDTH + ty, col, N)];
        else
            B_tile[ty][tx] = make_double2(0.0, 0.0);

        __syncthreads();   // Ensure all threads finish loading the tiles

        // Compute the value of C for the current thread
        for (int k = 0; k < TILE_WIDTH; ++k) {
           // Load a tile of matrix A in column-major order
            double realPart = A_tile[ty][k].x * B_tile[k][tx].x - A_tile[ty][k].y * B_tile[k][tx].y;
            double imagPart = A_tile[ty][k].x * B_tile[k][tx].y + A_tile[ty][k].y * B_tile[k][tx].x;

            value.x += realPart;
            value.y += imagPart;
        }

        __syncthreads();  // Ensure all threads finish computation for this tile before loading the next
    }

    // Store the result in C using column-major order
    if (row < N && col < N) {
        C[FORTRAN_OFFSET(row, col, N)] = value;
    }
}

// Host function to launch the kernel
__host__ void matrixMultiply_GPU(int N, const floatTypeCUDA* A, const floatTypeCUDA* B, floatTypeCUDA* C, int* flags, int flagCount) {
    dim3 dimGrid((N - 1) / TILE_WIDTH + 1, (N - 1) / TILE_WIDTH + 1, 1);
    dim3 dimBlock(TILE_WIDTH, TILE_WIDTH, 1);

    // Extract flag values (if needed)
    int flag0 = (flagCount > 0) ? flags[0] : 0;
    int flag1 = (flagCount > 1) ? flags[1] : 0;
    int flag2 = (flagCount > 2) ? flags[2] : 0;

    // Launch the matrix multiplication kernel
    matrixMultiplyKernel_GPU<<<dimGrid, dimBlock>>>(N, A, B, C, flag0, flag1, flag2);
}
