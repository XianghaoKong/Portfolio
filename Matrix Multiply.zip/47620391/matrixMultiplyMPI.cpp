#include "matrixMultiplyMPI.h"
#include "matrixMultiply.h"

void matrixMultiply_MPI(int N, const floatType* A, const floatType* B, floatType* C, int* flags, int flagCount)
{
    // Initialize MPI
    int mpi_initialized;
    MPI_Initialized(&mpi_initialized);
    if (!mpi_initialized) {
        MPI_Init(NULL, NULL);
    }

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Initialize C to zero
    memset(C, 0, sizeof(floatType) * N * N);

    // Perform matrix multiplication on each node
    matrixMultiply(N, A, B, C, flags, flagCount);

   
    MPI_Datatype MPI_COMPLEX_DOUBLE = MPI_C_DOUBLE_COMPLEX;

    MPI_Allreduce(MPI_IN_PLACE, C, N * N, MPI_COMPLEX_DOUBLE, MPI_SUM, MPI_COMM_WORLD);

    // Since all nodes computed the same result, dividing by the number of nodes restores the correct values
    if (size > 1) {
        for (int i = 0; i < N * N; ++i) {
            C[i] /= static_cast<double>(size);
        }
    }

    // Finalize MPI if we initialized it
    int mpi_finalized;
    MPI_Finalized(&mpi_finalized);
    if (!mpi_finalized && !mpi_initialized) {
        MPI_Finalize();
    }
}
