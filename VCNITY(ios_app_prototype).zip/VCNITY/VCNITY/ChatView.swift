import SwiftUI

struct ChatView: View {
    let user: VerifiedUser
    @State private var message = ""
    @State private var messages: [String]

    init(user: VerifiedUser) {
        self.user = user
        _messages = State(initialValue: ["\(user.name): Hi there 👋", "How are you doing today?"])
    }

    var body: some View {
        VStack {
            ScrollView {
                VStack(spacing: 10) {
                    ForEach(messages, id: \.self) { msg in
                        if msg.starts(with: "You:") {
                            HStack {
                                Spacer()
                                Text(msg.replacingOccurrences(of: "You:", with: ""))
                                    .padding()
                                    .background(Color.blue.opacity(0.8))
                                    .foregroundColor(.white)
                                    .cornerRadius(15)
                                    .frame(maxWidth: 250, alignment: .trailing)
                            }
                            .transition(.move(edge: .trailing))
                        } else {
                            HStack {
                                Text(msg)
                                    .padding()
                                    .background(Color.gray.opacity(0.2))
                                    .cornerRadius(15)
                                    .frame(maxWidth: 250, alignment: .leading)
                                Spacer()
                            }
                            .transition(.move(edge: .leading))
                        }
                    }
                }
                .padding()
            }
            .animation(.easeInOut, value: messages)

            HStack {
                TextField("Type a message...", text: $message)
                    .textFieldStyle(.roundedBorder)

                Button("Send") {
                    if !message.isEmpty {
                        withAnimation {
                            messages.append("You: \(message)")
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                            withAnimation {
                                messages.append("\(user.name): Thanks for your message! 😊")
                            }
                        }
                        message = ""
                    }
                }
                .buttonStyle(.borderedProminent)
            }
            .padding()
        }
        .navigationTitle("Chat with \(user.name)")
        .background(Color(.systemGroupedBackground))
    }
}
