import SwiftUI

@main
struct VCNITYApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationStack{
                VerificationView()
            }
        }
    }
}

