import SwiftUI

struct ProfileDetailView: View {
    let user: VerifiedUser
    @State private var showChat = false
    @State private var showLimitAlert = false
    
    @AppStorage("chatCount") private var chatCount = 0
    @AppStorage("chatDate") private var chatDate = ""
    @AppStorage("chattedUsers") private var chattedUsersString = ""  // 储存已聊天的用户ID列表
    
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.blue.opacity(0.3), .purple.opacity(0.2)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack(spacing: 25) {
                Circle()
                    .fill(Color.white.opacity(0.9))
                    .frame(width: 120, height: 120)
                    .overlay(
                        Image(systemName: user.verified ? "checkmark.seal.fill" : "person.fill")
                            .font(.largeTitle)
                            .foregroundColor(user.verified ? .blue : .gray)
                            .scaleEffect(user.verified ? 1.2 : 1.0)
                            .animation(.easeInOut, value: user.verified)
                    )
                    .shadow(radius: 8)
                
                Text(user.name)
                    .font(.system(.largeTitle, design: .rounded))
                    .bold()
                
                Text("\(user.year) • \(user.major)")
                    .font(.title3)
                    .foregroundColor(.secondary)
                
                Text("Interests: " + user.interests.joined(separator: ", "))
                    .font(.body)
                    .multilineTextAlignment(.center)
                    .padding()
                
                HStack(spacing: 30) {
                    Button(action: handleChatRequest) {
                        Label("Chat", systemImage: "message.fill")
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.blue)
                    
                    Button(action: {}) {
                        Label("Connect", systemImage: "person.badge.plus")
                    }
                    .buttonStyle(.bordered)
                }
                
                Text("Remaining new chats today: \(max(0, 5 - chatCount))")
                    .font(.caption)
                    .foregroundColor(chatCount >= 5 ? .red : .gray)
                    .padding(.top, 5)
                
                Spacer()
            }
            .padding()
        }
        .navigationTitle("Profile")
        .sheet(isPresented: $showChat) {
            ChatView(user: user)
        }
        .alert("Daily Chat Limit Reached", isPresented: $showLimitAlert) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("You’ve reached your daily chat limit of 5 new conversations. Please try again tomorrow.")
        }
        .onAppear {
            resetIfNewDay()
        }
    }
    
    // MARK: - Logic
    
    func handleChatRequest() {
        let today = formattedDate()
        if chatDate != today {
            resetIfNewDay()
        }
        
        var chattedUsers = chattedUsersString.split(separator: ",").map { String($0) }
        
        if chattedUsers.contains(user.name) {
            showChat = true
        } else {
            if chatCount >= 5 {
                showLimitAlert = true
            } else {
                chatCount += 1
                chattedUsers.append(user.name)
                chattedUsersString = chattedUsers.joined(separator: ",")
                showChat = true
            }
        }
    }
    
    func resetIfNewDay() {
        chatDate = formattedDate()
        chatCount = 0
        chattedUsersString = ""
    }
    
    func formattedDate() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: Date())
    }
}
