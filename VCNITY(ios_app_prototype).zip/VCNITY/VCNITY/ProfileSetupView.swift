import SwiftUI

struct ProfileSetupView: View {
    @State private var nickname = ""
    @State private var major = ""
    @State private var year = ""
    @State private var newInterest = ""
    @State private var selectedInterests: [String] = []
    @State private var navigateToHome = false
    @State private var autoSuggested: [String] = []
    @State private var selectedAvatar: String? = nil

    let baseInterests = [
        "AI", "Design", "Sports", "Music", "Travel", "Reading",
        "Gaming", "Wellbeing", "Volunteering", "Robotics"
    ]
    
    let avatarOptions = [
        "person.crop.circle.fill",
        "person.fill",
        "person.circle.fill",
        "face.smiling.fill",
        "brain.head.profile",
        "studentdesk"
    ]
    
    let autoSuggestionsByMajor: [String: [String]] = [
        "computer science": ["AI", "Coding", "Machine Learning", "Data Science"],
        "software engineering": ["Coding", "UI/UX", "AI", "Gaming"],
        "design": ["UX/UI", "Creativity", "Art", "Fashion"],
        "business": ["Marketing", "Entrepreneurship", "Finance"],
        "psychology": ["Wellbeing", "Neuroscience", "Counseling"],
        "engineering": ["Robotics", "3D Printing", "Innovation"],
        "architecture": ["Art", "Sketching", "Sustainability"],
        "law": ["Ethics", "Debating", "Public Policy"],
        "education": ["Teaching", "Children", "Learning"],
        "media": ["Filmmaking", "Writing", "Photography"]
    ]

    var body: some View {
        ZStack {
            LinearGradient(colors: [.blue.opacity(0.15), .purple.opacity(0.15)],
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing)
                .ignoresSafeArea()

            ScrollView {
                VStack(spacing: 25) {
                    Text("Set Up Your Profile")
                        .font(.system(.largeTitle, design: .rounded))
                        .bold()
                        .padding(.top, 20)
                    
                    VStack(spacing: 10) {
                        Text("Choose Your Avatar")
                            .font(.headline)

                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 20) {
                                ForEach(avatarOptions, id: \.self) { icon in
                                    Image(systemName: icon)
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 70, height: 70)
                                        .padding()
                                        .background(
                                            Circle()
                                                .fill(selectedAvatar == icon ? Color.blue.opacity(0.3) : Color.white)
                                        )
                                        .clipShape(Circle())
                                        .overlay(
                                            Circle().stroke(selectedAvatar == icon ? Color.blue : Color.gray.opacity(0.3), lineWidth: 3)
                                        )
                                        .onTapGesture {
                                            withAnimation {
                                                selectedAvatar = icon
                                            }
                                        }
                                }
                            }
                            .padding(.horizontal)
                        }
                    }
                    
                    VStack(alignment: .leading, spacing: 12) {
                        TextField("Nickname", text: $nickname)
                            .textFieldStyle(.roundedBorder)
                        TextField("Major (e.g., Computer Science)", text: $major)
                            .textFieldStyle(.roundedBorder)
                            .onChange(of: major.lowercased()) { newValue in
                                updateAutoSuggestions(for: newValue)
                            }
                        TextField("Year (e.g., 2nd Year)", text: $year)
                            .textFieldStyle(.roundedBorder)
                    }
                    .padding(.horizontal)

                    if !autoSuggested.isEmpty {
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Recommended for your Major:")
                                .font(.headline)
                                .padding(.horizontal)
                            
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 10) {
                                    ForEach(autoSuggested, id: \.self) { interest in
                                        Button(action: { toggleInterest(interest) }) {
                                            Text(interest)
                                                .padding(.horizontal, 10)
                                                .padding(.vertical, 8)
                                                .background(selectedInterests.contains(interest) ? Color.blue : Color.gray.opacity(0.2))
                                                .foregroundColor(selectedInterests.contains(interest) ? .white : .black)
                                                .cornerRadius(20)
                                        }
                                    }
                                }
                                .padding(.horizontal)
                            }
                        }
                    }

                    VStack(alignment: .leading, spacing: 10) {
                        Text("Suggested Interests")
                            .font(.headline)
                            .padding(.horizontal)

                        let columns = [GridItem(.adaptive(minimum: 100))]
                        LazyVGrid(columns: columns, spacing: 10) {
                            ForEach(baseInterests, id: \.self) { interest in
                                Button(action: { toggleInterest(interest) }) {
                                    Text(interest)
                                        .font(.subheadline)
                                        .padding(.vertical, 8)
                                        .frame(maxWidth: .infinity)
                                        .background(selectedInterests.contains(interest) ? Color.blue.opacity(0.8) : Color.gray.opacity(0.2))
                                        .foregroundColor(selectedInterests.contains(interest) ? .white : .black)
                                        .cornerRadius(10)
                                }
                            }
                        }
                        .padding(.horizontal)
                    }

                    VStack(alignment: .leading, spacing: 10) {
                        Text("Add Your Own Interests")
                            .font(.headline)
                            .padding(.horizontal)

                        HStack {
                            TextField("Type an interest...", text: $newInterest)
                                .textFieldStyle(.roundedBorder)
                            Button(action: addInterest) {
                                Image(systemName: "plus.circle.fill")
                                    .font(.title2)
                                    .foregroundColor(newInterest.isEmpty ? .gray : .blue)
                            }
                            .disabled(newInterest.isEmpty)
                        }
                        .padding(.horizontal)

                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack {
                                ForEach(selectedInterests, id: \.self) { interest in
                                    HStack(spacing: 4) {
                                        Text(interest)
                                            .padding(.horizontal, 10)
                                            .padding(.vertical, 6)
                                            .background(Color.blue.opacity(0.8))
                                            .foregroundColor(.white)
                                            .cornerRadius(20)
                                        Button(action: {
                                            selectedInterests.removeAll { $0 == interest }
                                        }) {
                                            Image(systemName: "xmark.circle.fill")
                                                .foregroundColor(.white.opacity(0.9))
                                        }
                                    }
                                }
                            }
                            .padding(.horizontal)
                        }
                    }

                    NavigationLink(destination: HomeView(), isActive: $navigateToHome) {
                        EmptyView()
                    }

                    Button(action: { navigateToHome = true }) {
                        Text("Complete Setup")
                            .font(.headline)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(isFormValid ? Color.blue : Color.gray.opacity(0.5))
                            .foregroundColor(.white)
                            .cornerRadius(12)
                    }
                    .padding(.horizontal)
                    .disabled(!isFormValid)

                    Spacer(minLength: 40)
                }
                .padding(.bottom, 20)
            }
        }
    }

    // MARK: - Computed
    var isFormValid: Bool {
        !nickname.isEmpty && !major.isEmpty && !year.isEmpty && selectedAvatar != nil && !selectedInterests.isEmpty
    }

    // MARK: - Functions
    func toggleInterest(_ interest: String) {
        if selectedInterests.contains(interest) {
            selectedInterests.removeAll { $0 == interest }
        } else {
            selectedInterests.append(interest)
        }
    }

    func addInterest() {
        let trimmed = newInterest.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, !selectedInterests.contains(trimmed) else { return }
        selectedInterests.append(trimmed)
        newInterest = ""
    }

    func updateAutoSuggestions(for major: String) {
        for (key, suggestions) in autoSuggestionsByMajor {
            if major.contains(key) {
                autoSuggested = suggestions
                return
            }
        }
        autoSuggested = []
    }
}

