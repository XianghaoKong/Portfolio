import SwiftUI

struct VerificationView: View {
    @State private var studentID = ""
    @State private var fullName = ""
    @State private var verificationPassed = false
    @State private var showLoading = false

    var body: some View {
        ZStack {
            LinearGradient(colors: [.blue.opacity(0.3), .purple.opacity(0.2)],
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing)
                .ignoresSafeArea()
            
            VStack(spacing: 25) {
                Text("VCINITY Verification")
                    .font(.system(.largeTitle, design: .rounded))
                    .bold()
                    .padding(.top, 40)
                
                VStack(alignment: .leading, spacing: 12) {
                    Text("Student ID")
                        .font(.headline)
                    TextField("Enter your student ID", text: $studentID)
                        .textFieldStyle(.roundedBorder)
                    
                    Text("Full Name")
                        .font(.headline)
                    TextField("Enter your full name", text: $fullName)
                        .textFieldStyle(.roundedBorder)
                }
                .padding(.horizontal)
                
                if showLoading {
                    ProgressView("Verifying face...")
                        .progressViewStyle(.circular)
                        .padding()
                } else {
                    Button(action: startVerification) {
                        Label("Start Face Verification", systemImage: "faceid")
                            .font(.headline)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background((studentID.isEmpty || fullName.isEmpty) ? Color.gray.opacity(0.5) : Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(12)
                    }
                    .padding(.horizontal)
                    .disabled(studentID.isEmpty || fullName.isEmpty)
                }
                
                Spacer()
                
                NavigationLink(destination: ProfileSetupView(), 
                               isActive: $verificationPassed) {
                    EmptyView()
                }
            }
        }
    }

    func startVerification() {
        showLoading = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            showLoading = false
            verificationPassed = true
        }
    }
}

