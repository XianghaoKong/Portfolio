import SwiftUI

struct HomeView: View {
    @State private var searchText = ""
    
    @AppStorage("chatCount") private var chatCount = 0
    @AppStorage("chatDate") private var chatDate = ""

    var filteredUsers: [VerifiedUser] {
        if searchText.isEmpty { return sampleUsers }
        let keyword = searchText.lowercased()
        return sampleUsers.filter { user in
            user.name.lowercased().contains(keyword) ||
            user.major.lowercased().contains(keyword) ||
            user.interests.contains(where: { $0.lowercased().contains(keyword) })
        }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(colors: [.blue.opacity(0.15), .purple.opacity(0.1)],
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing)
                    .ignoresSafeArea()

                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        Text("Find Verified Friends")
                            .font(.system(.largeTitle, design: .rounded))
                            .bold()
                            .padding(.horizontal)

                        TextField("Search by name, major, or interest...", text: $searchText)
                            .textFieldStyle(.roundedBorder)
                            .padding(.horizontal)
                    
                        VStack(alignment: .leading, spacing: 6) {
                            HStack {
                                Text("Chats started today: \(chatCount)/5")
                                    .font(.subheadline)
                                    .foregroundColor(chatCount >= 5 ? .red : .secondary)
                                Spacer()
                            }

                            ProgressView(value: Double(chatCount), total: 5)
                                .accentColor(chatCount >= 5 ? .red : .blue)
                                .padding(.trailing)
                        }
                        .padding(.horizontal)
                        .padding(.bottom, 5)
                        .onAppear {
                            resetIfNewDay()
                        }

                        LazyVStack(spacing: 16) {
                            ForEach(filteredUsers) { user in
                                NavigationLink(destination: ProfileDetailView(user: user)) {
                                    VStack(alignment: .leading, spacing: 8) {
                                        HStack(spacing: 15) {
                                            Circle()
                                                .fill(LinearGradient(
                                                    gradient: Gradient(colors: [.blue.opacity(0.6), .purple.opacity(0.4)]),
                                                    startPoint: .topLeading, endPoint: .bottomTrailing))
                                                .frame(width: 60, height: 60)
                                                .overlay(
                                                    Image(systemName: user.verified ? "checkmark.seal.fill" : "person.fill")
                                                        .font(.title2)
                                                        .foregroundColor(.white)
                                                )

                                            VStack(alignment: .leading, spacing: 4) {
                                                Text(user.name)
                                                    .font(.headline)
                                                    .foregroundColor(.primary)
                                                Text("\(user.year) • \(user.major)")
                                                    .font(.subheadline)
                                                    .foregroundColor(.secondary)
                                                Text(user.interests.joined(separator: ", "))
                                                    .font(.caption)
                                                    .foregroundColor(.secondary)
                                            }
                                            Spacer()
                                        }
                                    }
                                    .padding()
                                    .background(.thinMaterial)
                                    .cornerRadius(16)
                                    .shadow(color: .gray.opacity(0.2), radius: 5, x: 0, y: 2)
                                    .padding(.horizontal)
                                }
                            }
                        }
                        .padding(.bottom, 20)
                    }
                    .padding(.top, 10)
                }
            }
            .navigationTitle("Verified Friends")
        }
    }

    // MARK: - Helper Function
    func resetIfNewDay() {
        let today = formattedDate()
        if chatDate != today {
            chatDate = today
            chatCount = 0
        }
    }

    func formattedDate() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: Date())
    }
}
