import Foundation

struct VerifiedUser: Identifiable {
    let id = UUID()
    let name: String
    let year: String
    let major: String
    let interests: [String]
    let verified: Bool
}

let sampleUsers = [
    VerifiedUser(name: "James H.", year: "3rd Year", major: "Computer Science", interests: ["AI", "Basketball"], verified: true),
    VerifiedUser(name: "Grace M.", year: "2nd Year", major: "Psychology", interests: ["Wellbeing", "Reading"], verified: true),
    VerifiedUser(name: "Leo W.", year: "1st Year", major: "Business", interests: ["Marketing", "Travel"], verified: true),
    VerifiedUser(name: "Sophie L.", year: "4th Year", major: "Engineering", interests: ["Design", "Robotics"], verified: true),
    VerifiedUser(name: "Ethan K.", year: "2nd Year", major: "Law", interests: ["Debating", "Ethics"], verified: true),
    VerifiedUser(name: "Mia C.", year: "1st Year", major: "Architecture", interests: ["Art", "Sketching"], verified: true),
    VerifiedUser(name: "Noah T.", year: "3rd Year", major: "Data Science", interests: ["Machine Learning", "Volunteering"], verified: true),
    VerifiedUser(name: "Ava R.", year: "2nd Year", major: "Nursing", interests: ["Healthcare", "Yoga"], verified: true),
    VerifiedUser(name: "William P.", year: "4th Year", major: "Finance", interests: ["Investing", "Networking"], verified: true),
    VerifiedUser(name: "Olivia J.", year: "3rd Year", major: "Education", interests: ["Children", "Photography"], verified: true),
    VerifiedUser(name: "Lucas B.", year: "1st Year", major: "Environmental Science", interests: ["Sustainability", "Hiking"], verified: true),
    VerifiedUser(name: "Isabella N.", year: "4th Year", major: "Media Studies", interests: ["Filmmaking", "Writing"], verified: true),
    VerifiedUser(name: "Benjamin D.", year: "2nd Year", major: "Software Engineering", interests: ["Coding", "Gaming"], verified: true),
    VerifiedUser(name: "Charlotte S.", year: "3rd Year", major: "Design", interests: ["UX/UI", "Fashion"], verified: true),
    VerifiedUser(name: "Daniel W.", year: "4th Year", major: "Mechanical Engineering", interests: ["Cars", "3D Printing"], verified: true),
    VerifiedUser(name: "Emily F.", year: "1st Year", major: "Public Health", interests: ["Mental Health", "Volunteering"], verified: true)
]
