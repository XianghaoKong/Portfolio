//
//  VCNITYTests.swift
//  VCNITYTests
//
//  Created by 孔祥灏 on 26/10/2025.
//

import Testing
@testable import VCNITY

struct VCNITYTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
